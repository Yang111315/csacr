import sys
import os

current_dir = os.path.dirname(os.path.abspath(__file__))
parent_dir = os.path.dirname(current_dir)

# 将上一级目录添加到系统搜索路径的最前面
if parent_dir not in sys.path:
    sys.path.insert(0, parent_dir)
import os
import json
import time
from pathlib import Path
from concurrent.futures import ThreadPoolExecutor, as_completed
from tqdm import tqdm
from openai import OpenAI, RateLimitError, APIError, APITimeoutError, APIConnectionError


import model.LLM_Model
import prompt.Prompt
import inference.llm_inference
from android_knowledge.retrieval_knowledge import retrieve_by_type_and_show


vacur = "./vacur.json" #you each vacur data path

def init_llm():
    llm, client = model.LLM_Model.QWEN_MODEL, model.LLM_Model.QWEN_CLIENT # change client
    return llm, client


def filter_compatible_elements(retrieval_results, min_sdk, target_sdk):
    """
    过滤掉不符合版本的 API，返回符合版本的数组。
    对应论文公式：(since_api <= min_sdk) 且 (deprecation is null 或 deprecation > target_sdk) 且 (未被 removed)
    """
    valid_elements = []

    for res in retrieval_results:
        meta = res.get("meta", {})

        # 1. 获取并处理 since_api (引入版本)
        try:
            since_api = int(meta.get("since_api", 1))
        except (ValueError, TypeError):
            since_api = 1

        # 2. 获取并处理 deprecation (废弃版本)
        dep_raw = meta.get("evolution_direction")
        dep_api = None
        if dep_raw and str(dep_raw).lower().strip() not in ["null", "none", "deprecated", "removed"]:
            try:
                dep_api = int(dep_raw)
            except (ValueError, TypeError):
                pass

        # 3. 获取 evolution_direction
        evo_dir = str(meta.get("evolution_direction", "")).lower().strip()

        # 4. 核心判断逻辑
        # (1) 引入版本 <= 项目最低版本
        cond_since = (since_api <= min_sdk)
        # (2) 没废弃，或者废弃版本 > 项目目标版本
        cond_dep = (dep_api is None) or (dep_api > target_sdk)
        # (3) 没有被彻底移除
        cond_removed = (evo_dir != "removed")

        # 全部满足则保留
        if cond_since and cond_dep and cond_removed:
            valid_elements.append(res)

    return valid_elements


def build_ccp(multi_intents, filtered_apis, cer, max_candidates=15):

    final_candidates = filtered_apis[:max_candidates]
    candidate_list = []
    for api in final_candidates:
        # 假设你的 API 结构里包含 api_id 和 desc
        candidate_info = {
            "api_id": api["api_id"],
            "desc": api.get("desc", "")[:100]  # 描述截断，防 Token 爆炸
        }
        candidate_list.append(candidate_info)

    # 2. 组装 CCP 字典
    ccp = {
        "functional_intents": multi_intents,
        "feasible_candidates": candidate_list,
        "environmental_context": {
            "component_type": cer.get("c", "unknown"),
            "thread_affinity": cer.get("t", "unknown"),
            "lifecycle_stage": cer.get("l", "other"),
            "platform_restriction": cer.get("r", "no_restriction")
        }
    }

    return ccp

if __name__ == "__main__":

    llm, client = init_llm()
    with open(vacur, 'r', encoding='utf-8') as f:
        data_vacur = json.load(f)
    rec_type = "api" # constant, manifest, you can change this to different recommendation task
    code_function_intent_list = inference.llm_inference.function_extract(llm, client, data_vacur)


    retrieval_results = []
    for i in range(0, len(code_function_intent_list)):
        results = retrieve_by_type_and_show(code_function_intent_list[i], rec_type, 20)
        for j in range(0, len(results)):
            retrieval_results.append(results[j])

    # exclude the wrong version retrieval results
    matched_version_results = []
    for m in range(0, len(retrieval_results)):
        filter_list = filter_compatible_elements(retrieval_results, data_vacur.versionInfo.minSdkVersion, data_vacur.versionInfo.targetSdkVersion)
        for k in range(0, len(filter_list)):
            matched_version_results.append(filter_list[k])

    cer = inference.llm_inference.cer_extract(llm, client, data_vacur)
    print(cer)
    ccp = build_ccp(code_function_intent_list, matched_version_results, cer)

    rerank_result = inference.llm_inference.rerank(llm, client, data_vacur, ccp)
    print(rerank_result)







