import sys
import os

# 获取当前 main.py 所在的目录 (即 csacr 目录)
current_dir = os.path.dirname(os.path.abspath(__file__))
# 获取 csacr 的上一级目录
parent_dir = os.path.dirname(current_dir)

# 将上一级目录添加到系统搜索路径的最前面
if parent_dir not in sys.path:
    sys.path.insert(0, parent_dir)

import os
import json
import time
from pathlib import Path
from concurrent.futures import ThreadPoolExecutor, as_completed
from tqdm import tqdm
from openai import OpenAI, RateLimitError, APIError, APITimeoutError, APIConnectionError



DS_MODEL = "deepseek-chat" # qwen-plus
DS_API_KEY = "" # add your key
DS_CLIENT = OpenAI(
    api_key=DS_API_KEY,
    base_url="https://api.deepseek.com/v1"
)


QWEN_MODEL = "qwen-plus" #
QWEN_API_KEY = "" # add your key
QWEN_CLIENT = OpenAI(
    api_key=QWEN_API_KEY,
    base_url="https://dashscope.aliyuncs.com/compatible-mode/v1" #
)

