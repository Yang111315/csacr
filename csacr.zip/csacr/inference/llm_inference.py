import sys
import os

# 获取当前 main.py 所在的目录 (即 csacr 目录)
current_dir = os.path.dirname(os.path.abspath(__file__))
# 获取 csacr 的上一级目录
parent_dir = os.path.dirname(current_dir)

# 将上一级目录添加到系统搜索路径的最前面
if parent_dir not in sys.path:
    sys.path.insert(0, parent_dir)

import os
import json
import time
from pathlib import Path
from concurrent.futures import ThreadPoolExecutor, as_completed
from tqdm import tqdm
from openai import OpenAI, RateLimitError, APIError, APITimeoutError, APIConnectionError

MAX_WORKERS = 15
MAX_RETRIES = 3
max_retries = 3

from csacr.prompt import Prompt

def function_extract(llm, client, vacur):
    print(vacur)
    full_prompt = Prompt.FI_EXTRACTION_PROMPT.format(VACUR=vacur.strip())
    for attempt in range(max_retries):
        try:
            response = client.chat.completions.create(
                model=llm,
                messages=[
                    {"role": "user", "content": full_prompt}
                ],
                temperature=0.0,
                top_p=0.9,
                max_tokens=3000,
                timeout=60.0
            )

            raw_output = response.choices[0].message.content.strip()
            if not raw_output:
                raise ValueError("Empty response from model")

            # 尝试清理可能的 Markdown 包裹
            if raw_output.startswith("```"):
                start = raw_output.find('{')
                end = raw_output.rfind('}')
                if start != -1 and end != -1:
                    raw_output = raw_output[start:end + 1]
                else:
                    raise ValueError("No JSON braces found in markdown-wrapped response")

            # 解析 JSON
            result = json.loads(raw_output)

            # 验证结构
            if not isinstance(result, dict) or "predictions" not in result:
                raise ValueError("Missing 'predictions' key in JSON")

            predictions = result["predictions"]
            if not isinstance(predictions, list) or len(predictions) != 10:
                raise ValueError(
                    f"Expected 10 predictions, got {len(predictions) if isinstance(predictions, list) else 'not a list'}")

            return result

        except (json.JSONDecodeError, ValueError) as e:
            print(f"⚠️  Parse error (attempt {attempt + 1}/{max_retries}): {e}")
            if attempt == max_retries - 1:
                raise RuntimeError(f"Failed to parse valid JSON after {max_retries} attempts. Last output:\n{raw_output}")
            time.sleep(1)  # 短暂等待后重试

        except (RateLimitError, APITimeoutError, APIError) as e:
            print(f"⚠️  API error (attempt {attempt + 1}/{max_retries}): {e}")
            if attempt == max_retries - 1:
                raise
            time.sleep(2 ** attempt)  # 指数退避

        except Exception as e:
            print(f"💥 Unexpected error: {e}")
            raise

    raise RuntimeError("Unreachable: retry loop exited without success")









def cer_extract(llm, client, codeContext):

    LIFECYCLES_STR = "\n".join([
        f"  - If c is '{comp}': {', '.join(stages)}"
        for comp, stages in Prompt.VALID_LIFECYCLES.items()
    ])
    prompt = Prompt.CER_EXTRACTION_PROMPT.format(
        components = Prompt.VALID_COMPONENTS_LIST,
        threads = Prompt.VALID_THREADS_LIST,
        lifecycles = LIFECYCLES_STR,
        restrictions =Prompt. VALID_RESTRICTIONS_LIST,
        code_snippet = codeContext
    )
    raw_output = ""

    # 2. 重试循环
    for attempt in range(max_retries):
        try:
            response = client.chat.completions.create(
                model=llm,
                messages=[
                    {"role": "user", "content": prompt}  # 修复：把 full_prompt 改为 prompt
                ],
                temperature=0.0,
                top_p=0.9,
                max_tokens=300,  # 提取 JSON 不需要 3000 这么长，300 足够了
                timeout=60.0
            )

            raw_output = response.choices[0].message.content.strip()
            if not raw_output:
                raise ValueError("Empty response from model")

            # 清理可能的 Markdown 包裹
            if raw_output.startswith("```"):
                start = raw_output.find('{')
                end = raw_output.rfind('}')
                if start != -1 and end != -1:
                    raw_output = raw_output[start:end + 1]
                else:
                    raise ValueError("No JSON braces found in markdown-wrapped response")

            # 解析 JSON
            result = json.loads(raw_output)

            # 验证结构（修复：验证 c, t, l, r 是否都在）
            if not isinstance(result, dict) or not all(k in result for k in ["c", "t", "l", "r"]):
                raise ValueError("Missing c, t, l, or r keys in JSON output")

            # --- 3. 严格后处理校验（兜底机制） ---
            final_cer = {
                "c": result.get("c", "unknown"),
                "t": result.get("t", "unknown"),
                "l": result.get("l", "other"),
                "r": result.get("r", "other")
            }

            # 强制校验 Component (c)
            if final_cer["c"] not in Prompt.VALID_COMPONENTS:
                final_cer["c"] = "unknown"

            # 强制校验 Thread (t)
            if final_cer["t"] not in Prompt.VALID_THREADS:
                final_cer["t"] = "unknown"

            # 强制校验 Lifecycle (l)
            if final_cer["l"] not in Prompt.VALID_LIFECYCLES:
                final_cer["l"] = "other"

            # 强制校验 Restriction (r)
            if final_cer["r"] not in Prompt.VALID_RESTRICTIONS:
                final_cer["r"] = "other"

            # 成功则返回清洗后的字典

            return final_cer

        except (json.JSONDecodeError, ValueError) as e:
            print(f"⚠️ Parse error (attempt {attempt + 1}/{max_retries}): {e}")
            if attempt == max_retries - 1:
                # 兜底：重试彻底失败时，返回安全的默认值，防止 Pipeline 崩溃
                print(f"💥 Failed after {max_retries} attempts. Returning fallback CER.")
                return {"c": "unknown", "t": "unknown", "l": "other", "r": "other"}
            time.sleep(1)

        except (RateLimitError, APITimeoutError, APIError) as e:
            print(f"⚠️ API error (attempt {attempt + 1}/{max_retries}): {e}")
            if attempt == max_retries - 1:
                return {"c": "unknown", "t": "unknown", "l": "other", "r": "other"}
            time.sleep(2 ** attempt)

        except Exception as e:
            print(f"💥 Unexpected error: {e}")
            return {"c": "unknown", "t": "unknown", "l": "other", "r": "other"}

    return {"c": "unknown", "t": "unknown", "l": "other", "r": "other"}


def rerank(llm, client, vacur, ccp):
    print("recommendation rerank")
    full_prompt = Prompt.RERANK_PROMPT.format(
        vacur=vacur,
        ccp_json_str = ccp
    )
    for attempt in range(max_retries):
        try:
            response = client.chat.completions.create(
                model=llm,
                messages=[
                    {"role": "user", "content": full_prompt}
                ],
                temperature=0.0,
                top_p=0.9,
                max_tokens=3000,
                timeout=60.0
            )

            raw_output = response.choices[0].message.content.strip()
            if not raw_output:
                raise ValueError("Empty response from model")

            # 尝试清理可能的 Markdown 包裹
            if raw_output.startswith("```"):
                start = raw_output.find('{')
                end = raw_output.rfind('}')
                if start != -1 and end != -1:
                    raw_output = raw_output[start:end + 1]
                else:
                    raise ValueError("No JSON braces found in markdown-wrapped response")

            # 解析 JSON
            result = json.loads(raw_output)

            # 验证结构
            if not isinstance(result, dict) or "predictions" not in result:
                raise ValueError("Missing 'predictions' key in JSON")

            predictions = result["predictions"]
            if not isinstance(predictions, list) or len(predictions) != 10:
                raise ValueError(
                    f"Expected 10 predictions, got {len(predictions) if isinstance(predictions, list) else 'not a list'}")

            return result

        except (json.JSONDecodeError, ValueError) as e:
            print(f"⚠️  Parse error (attempt {attempt + 1}/{max_retries}): {e}")
            if attempt == max_retries - 1:
                raise RuntimeError(f"Failed to parse valid JSON after {max_retries} attempts. Last output:\n{raw_output}")
            time.sleep(1)  # 短暂等待后重试

        except (RateLimitError, APITimeoutError, APIError) as e:
            print(f"⚠️  API error (attempt {attempt + 1}/{max_retries}): {e}")
            if attempt == max_retries - 1:
                raise
            time.sleep(2 ** attempt)  # 指数退避

        except Exception as e:
            print(f"💥 Unexpected error: {e}")
            raise

    raise RuntimeError("Unreachable: retry loop exited without success")




