import sys
import os

# 获取当前 main.py 所在的目录 (即 csacr 目录)
current_dir = os.path.dirname(os.path.abspath(__file__))
# 获取 csacr 的上一级目录
parent_dir = os.path.dirname(current_dir)

# 将上一级目录添加到系统搜索路径的最前面
if parent_dir not in sys.path:
    sys.path.insert(0, parent_dir)



#function intent extraction
FI_EXTRACTION_PROMPT = """
Role Description & Target: You are an Android code analysis expert. Your task is to extract the high-level functional abstraction (F_A) from the given project information and code snippet.
Task Definition: You should summarize in one sentence what the code is doing, focusing on the “intent” rather than the implementation details.
Input Format: You will receive a tuple object containing the project’s version information, manifest configuration, and code context.
Output Requirement:  (1)Target the specific intent of the missing code element at the <HOLE> marker, based on its surrounding context; (2) Output only the F_A text, without any explanation or additional content; (3)Output 3-8 F_A candidates in a valid JSON array of strings; (4)Limit the length of each F_A to within 30 words;(5)Use the present tense and start with a verb
Example: A simplified example
        Input: {{"codeContext": {{
            "className": "MainActivity",
            "snippet": "Button btn = findViewById(R.id.button);\nbtn.<HOLE>;"}}}}
        Output: [
            "Set up a click listener for a button",
            "Handle button click events",
            "Define the action triggered by a button click"
        ]
Your Task Begin: {VACUR}
Output: To be done
"""



VALID_COMPONENTS = {
    "Activity", "Fragment", "Service", "BroadcastReceiver", "ContentProvider",
    "Application", "ViewModel", "View", "Adapter", "Dialog", "unknown"
}

VALID_THREADS = {"main", "background", "unknown"}

VALID_LIFECYCLES = {
    "Activity": [
        "onCreate", "onStart", "onResume", "onPause", "onStop", "onDestroy",
        "onRestart", "onSaveInstanceState", "onRestoreInstanceState", "onNewIntent",
        "onPostCreate", "onPostResume"
    ],
    "Fragment": [
        "onAttach", "onCreateView", "onViewCreated", "onActivityCreated", "onStart",
        "onResume", "onPause", "onStop", "onDestroyView", "onDestroy", "onDetach",
        "onSaveInstanceState", "onViewStateRestored", "onAttachFragment"
    ],
    "Service": [
        "onStartCommand", "onBind", "onUnbind", "onRebind", "onTaskRemoved", "onCreate", "onDestroy"
    ],
    "Receiver": ["onReceive"],
    "Provider": ["query", "insert", "update", "delete", "getType", "bulkInsert"],
    "Application": ["onCreate", "onTerminate", "onLowMemory", "onTrimMemory", "onConfigurationChanged"],
    "ViewModel": ["onCleared"],
    "Other": ["other"]
}

VALID_RESTRICTIONS = {
    "no_restriction", "foreground_required", "background_allowed",
    "window_token_required", "background_launch_restricted",
    "battery_optimization_ignored", "exact_alarm_permission_required",
    "notification_permission_required", "storage_permission_required",
    "location_permission_required", "external_storage_restricted", "other"
}

# 提前将集合转换为列表字符串，避免在 Prompt 模板中执行函数
VALID_COMPONENTS_LIST = list(VALID_COMPONENTS)
VALID_THREADS_LIST = list(VALID_THREADS)
VALID_LIFECYCLES_LIST = list(VALID_LIFECYCLES)
VALID_RESTRICTIONS_LIST = list(VALID_RESTRICTIONS)

#code environmental representation extraction prompt
CER_EXTRACTION_PROMPT = """You are an Android code analysis expert. Your task is to extract the Code Environmental Representation (CER) from the given code snippet.
The CER consists of four attributes (LCTR):
- c (Component Type): Choose strictly from {components}.
- t (Thread Affinity): Choose strictly from {threads}.
- l (Lifecycle Stage): Choose strictly from {lifecycles}.
- r (Platform Restriction): Choose strictly from {restrictions}.

Output Requirements: 
1. Output ONLY a valid JSON object without any markdown formatting (Do not use ```json).
2. Use lowercase for keys: "c", "t", "l", "r".
3. If uncertain, use "unknown" for c/t and "other" for l/r.

Example Input:
public class MyService extends Service {{
    @Override
    public void onCreate() {{
        super.onCreate();
        <HOLE>
    }}
}}
Example Output:
{{"c": "Service", "t": "main", "l": "onCreate", "r": "no_restriction"}}

Your Task:
Code Snippet:
{code_snippet}
"""

#code recommendation rerank prompt
RERANK_PROMPT =  """You are an expert Android developer. Your task is to rank the provided candidate APIs to fill in the <HOLE> marker.

### 1. code context:
{vacur}

### 2. Contextual Code Profile (CCP):
The CCP contains the extracted multi-perspective intents, the strict environmental constraints (CER), and the valid candidate APIs.
{ccp_json_str}

### 3. Instructions:
- Analyze the `functional_intents`. The correct API should satisfy the semantic meaning of these intents.
- Strictly respect the `environmental_context` (Component, Thread, Lifecycle). The recommended API MUST be legal in this environment.
- Rank the `feasible_candidates` based on how well they match both the intent and the environment. 
- Output ONLY a valid JSON list of strings containing the ranked API IDs. Do NOT include markdown formatting or any explanations.

"""