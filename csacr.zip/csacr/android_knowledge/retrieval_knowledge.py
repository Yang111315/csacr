import sys
import os

current_dir = os.path.dirname(os.path.abspath(__file__))
parent_dir = os.path.dirname(current_dir)

# 将上一级目录添加到系统搜索路径的最前面
if parent_dir not in sys.path:
    sys.path.insert(0, parent_dir)

import json
import re
import numpy as np
import faiss
from sentence_transformers import SentenceTransformer
from langchain_text_splitters import RecursiveCharacterTextSplitter
from nltk.corpus import stopwords
from sklearn.metrics.pairwise import cosine_similarity
import matplotlib.pyplot as plt
import seaborn as sns
import nltk
from transformers import AutoTokenizer

MODEL_NAME = 'BAAI/bge-large-en-v1.5'

api_file = '/content/drive/MyDrive/content/drive/MyDrive/api_test_data/final_all_base_and_evolution_without_extends.json'

INDEX_PATH = "/content/drive/MyDrive/content/drive/MyDrive/api_test_data/storage/large_model_faiss.index"
RECORDS_PATH = '/content/drive/MyDrive/content/drive/MyDrive/api_test_data/storage/original_records.json'

# 三种类型各自的映射文件
CHUNK_TO_API_PATH = '/content/drive/MyDrive/content/drive/MyDrive/api_test_data/storage/chunk_to_api_id.json'
CHUNK_TO_FIELD_PATH = '/content/drive/MyDrive/content/drive/MyDrive/api_test_data/storage/chunk_to_field_id.json'
CHUNK_TO_MANIFEST_PATH = '/content/drive/MyDrive/content/drive/MyDrive/api_test_data/storage/chunk_to_manifest_id.json'

# 三种类型各自的 FAISS 索引
API_INDEX_PATH = "/content/drive/MyDrive/content/drive/MyDrive/api_test_data/storage/api_large_model_faiss.index"
FIELD_INDEX_PATH = "/content/drive/MyDrive/content/drive/MyDrive/api_test_data/storage/field_large_model_faiss.index"
MANIFEST_INDEX_PATH = "/content/drive/MyDrive/content/drive/MyDrive/api_test_data/storage/manifest_large_model_faiss.index"

model = None
tokenizer = None


def download_model():
    global model, tokenizer
    if model is None:
        model = SentenceTransformer(MODEL_NAME, device='cuda')  # 或 cpu
        tokenizer = AutoTokenizer.from_pretrained(MODEL_NAME)


# ==============================
# 1. 加载三个独立 FAISS 索引
# ==============================
print("📂 Loading FAISS indexes...")

api_index = faiss.read_index(API_INDEX_PATH)
field_index = faiss.read_index(FIELD_INDEX_PATH)
manifest_index = faiss.read_index(MANIFEST_INDEX_PATH)

print(f"API index: {api_index.ntotal} vectors")
print(f"Field index: {field_index.ntotal} vectors")
print(f"Manifest index: {manifest_index.ntotal} vectors")


# ==============================
# 2. 加载原始 API 记录
# ==============================
print("📂 Loading original API records...")

with open(RECORDS_PATH, 'r', encoding='utf-8') as f:
    original_records = json.load(f)

# 构建 api_id → record 映射
api_id_to_record = {
    rec["api_id"]: rec
    for rec in original_records
    if rec.get("api_id")
}


# ==============================
# 3. 加载三种类型各自的 chunk 映射
# ==============================
print("🔗 Loading chunk mappings...")

with open(CHUNK_TO_API_PATH, 'r', encoding='utf-8') as f:
    chunk_to_api_id = json.load(f)

with open(CHUNK_TO_FIELD_PATH, 'r', encoding='utf-8') as f:
    chunk_to_field_id = json.load(f)

with open(CHUNK_TO_MANIFEST_PATH, 'r', encoding='utf-8') as f:
    chunk_to_manifest_id = json.load(f)


# ==============================
# 4. 根据 target_type 检索对应索引
# ==============================
def retrieve_by_type_and_show(query: str, target_type: str, top_k: int = 3):

    if model is None:
        download_model()

    """
    根据 target_type 选择对应的 FAISS 索引和映射文件，
    检索后返回完整 API metadata。
    """

    # 1. 根据 target_type 选择索引和映射
    target_type = target_type.lower().strip()

    if target_type == "api":
        selected_index = api_index
        selected_mapping = chunk_to_api_id

    elif target_type in ["field", "constant"]:
        selected_index = field_index
        selected_mapping = chunk_to_field_id

    elif target_type == "manifest":
        selected_index = manifest_index
        selected_mapping = chunk_to_manifest_id

    else:
        raise ValueError(
            f"Unsupported target_type: {target_type}. "
            f"Expected 'api', 'field'/'constant', or 'manifest'."
        )

    # 2. 编码 query（必须归一化，与构建索引时保持一致）
    query_emb = model.encode(
        [query],
        normalize_embeddings=True,
        convert_to_numpy=True
    ).astype(np.float32)

    # 3. 在对应的 FAISS 索引中检索
    search_k = min(top_k, selected_index.ntotal)

    if search_k == 0:
        return []

    scores, ids = selected_index.search(query_emb, search_k)

    # 4. 根据当前索引对应的映射文件还原 api_id
    results = []

    for score, chunk_id in zip(scores[0], ids[0]):

        if chunk_id < 0 or chunk_id >= len(selected_mapping):
            continue

        # 注意：chunk_id 是当前子索引中的局部 ID
        api_id = selected_mapping[int(chunk_id)]

        # 根据 api_id 获取完整记录
        record = api_id_to_record.get(api_id, {})

        results.append({
            "score": float(score),
            "chunk_id": int(chunk_id),
            "api_id": api_id,
            "record": record
        })

        if len(results) >= top_k:
            break

    # 5. 打印完整 API 信息
    print(f"\n🎯 Query: \"{query}\"")
    print(f"🎯 Target Type: {target_type}\n")

    for i, res in enumerate(results, 1):
        print(f"=== Result #{i} (Similarity: {res['score']:.4f}) ===")
        print(f"API ID: {res['api_id']}")
        print("Full Meta:")

        for k, v in res["record"].items():
            print(f"  • {k}: {v}")

        print("-" * 60)

    return results
