
import json
import os
import numpy as np
import faiss
from sentence_transformers import SentenceTransformer
from langchain_text_splitters import RecursiveCharacterTextSplitter
import nltk
from transformers import AutoTokenizer

# ==============================
# 1. 路径配置
# ==============================

api_file = '/content/drive/MyDrive/content/drive/MyDrive/api_test_data/final_all_base_and_evolution_without_extends.json'

output_dir = '/content/drive/MyDrive/content/drive/MyDrive/api_test_data/storage/'

os.makedirs(output_dir, exist_ok=True)

# 三个独立 FAISS 索引
API_INDEX_PATH = output_dir + 'api_large_model_faiss.index'
FIELD_INDEX_PATH = output_dir + 'field_large_model_faiss.index'
MANIFEST_INDEX_PATH = output_dir + 'manifest_large_model_faiss.index'

# 三个索引各自的 Chunk -> API ID 映射
API_MAPPING_PATH = output_dir + 'api_chunk_to_api_id.json'
FIELD_MAPPING_PATH = output_dir + 'field_chunk_to_api_id.json'
MANIFEST_MAPPING_PATH = output_dir + 'manifest_chunk_to_api_id.json'

# 原始记录
records_json_path = output_dir + 'original_records.json'


# ==============================
# 2. 加载模型
# ==============================

MODEL_NAME = 'BAAI/bge-large-en-v1.5'

model = None
tokenizer = None

def download_model():
    global model, tokenizer

    if model is None:
        nltk.download('punkt', quiet=True)

        model = SentenceTransformer(
            MODEL_NAME,
            device='cuda'
        )

        tokenizer = AutoTokenizer.from_pretrained(MODEL_NAME)


# ==============================
# 3. 初始化 Text Splitter
# ==============================

splitter = RecursiveCharacterTextSplitter(
    chunk_size=450,
    chunk_overlap=50,
    separators=["\n\n", "\n", ". ", "; ", " ", ""]
)


# ==============================
# 4. 加载原始 API 数据
# ==============================

print("📂 Loading original API data...")

with open(api_file, 'r', encoding='utf-8') as f:
    original_records = json.load(f)

# 保存原始记录
with open(records_json_path, 'w', encoding='utf-8') as f:
    json.dump(original_records, f, ensure_ascii=False)

print(f"💾 Original records saved: {records_json_path}")


# API ID -> Original Record
api_id_to_record = {
    rec["api_id"]: rec
    for rec in original_records
    if rec.get("api_id")
}


# ==============================
# 5. 根据 Type 构建 Chunk
# ==============================

all_chunks = []

# 将原始 type 统一映射到三个目标类型
TYPE_MAPPING = {
    "API": "api",
    "FIELD": "field",
    "MANIFEST": "manifest"
}

for rec in original_records:

    api_id = rec.get("api_id", "").strip()
    desc = rec.get("desc", "").strip()

    if not api_id:
        continue

    original_type = rec.get("type", "").strip().upper()

    target_type = TYPE_MAPPING.get(original_type)

    if target_type is None:
        print(f"⚠️ Unknown type: {original_type}, API ID: {api_id}")
        continue

    text = f"{api_id} {desc}".strip()

    if not text:
        continue

    if len(text) > 1500:

        chunks = splitter.split_text(desc)

        for chunk in chunks:

            if chunk.strip():

                all_chunks.append({
                    "text": f"{api_id} {chunk.strip()}",
                    "source_api_id": api_id,
                    "type": target_type
                })

    else:

        all_chunks.append({
            "text": text,
            "source_api_id": api_id,
            "type": target_type
        })


print(f"\nTotal chunks: {len(all_chunks)}")


# ==============================
# 6. 一次性生成所有 Embeddings
# ==============================

download_model()

print("🧠 Encoding all chunks...")

texts = [item["text"] for item in all_chunks]

embeddings = model.encode(
    texts,
    batch_size=256,
    normalize_embeddings=True,
    show_progress_bar=True,
    convert_to_numpy=True
)

embeddings = embeddings.astype(np.float32)


# ==============================
# 7. 按 Type 分组
# ==============================

type_to_index_path = {
    "api": API_INDEX_PATH,
    "field": FIELD_INDEX_PATH,
    "manifest": MANIFEST_INDEX_PATH
}

type_to_mapping_path = {
    "api": API_MAPPING_PATH,
    "field": FIELD_MAPPING_PATH,
    "manifest": MANIFEST_MAPPING_PATH
}

# 获取每个类型对应的 Embedding 下标
type_to_positions = {
    "api": [],
    "field": [],
    "manifest": []
}

for i, item in enumerate(all_chunks):

    target_type = item["type"]

    type_to_positions[target_type].append(i)


# ==============================
# 8. 分别建立三个 FAISS 索引
# ==============================

d = embeddings.shape[1]

for target_type in ["api", "field", "manifest"]:

    print(f"\nBuilding {target_type.upper()} index...")

    positions = type_to_positions[target_type]

    # 获取对应类型的 Embeddings
    type_embeddings = embeddings[positions]

    # 创建独立 FAISS 索引
    sub_index = faiss.IndexFlatIP(d)

    sub_index.add(type_embeddings)

    # 保存 FAISS 索引
    faiss.write_index(
        sub_index,
        type_to_index_path[target_type]
    )

    # 保存局部 FAISS ID -> API ID
    # 顺序必须与 sub_index.add() 时一致
    chunk_to_api_id = [
        all_chunks[pos]["source_api_id"]
        for pos in positions
    ]

    with open(
        type_to_mapping_path[target_type],
        'w',
        encoding='utf-8'
    ) as f:

        json.dump(chunk_to_api_id, f, ensure_ascii=False)

    print(f"✅ {target_type.upper()} index saved")
    print(f"   Total vectors: {sub_index.ntotal}")
    print(f"   Index path: {type_to_index_path[target_type]}")
    print(f"   Mapping path: {type_to_mapping_path[target_type]}")


print("\n🎉 All three FAISS indexes built successfully!")
