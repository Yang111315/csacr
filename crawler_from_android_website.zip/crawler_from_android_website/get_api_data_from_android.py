import requests  # 导入request模块
import re  # 导入re模块
from bs4 import BeautifulSoup
import json

android_base_url = "https://developer.android.com/"
base_diff_url = "https://developer.android.com/sdk/api_diff/%s/changes/"
version_list = ['34', '33', '32', '31', '30', '29', '28','27', '26', '25', '24', '23', '22', '21']
evolution_time_dict = {
     '34': '2023.06.07',
     '33': '2022.06.03',
     '32': '2021.12.06',
     '31': '2021.07.06',
     '30': '2020.05.28',
     '29': '2019.06.04',
     '28': '2018.06.01',
     '27': '2017.10.21',
     '26': '2017.06.01',
     '25': '2016.10.14',
     '24': '2016.06.13',
     '23': '2015.08.14',
     '22': '2015.02.19',
     '21': '2014.10.15'
}
platform_api_dict = {
    'android_14': '34',
    'android_13': '33',
    'android_12L': '32',
    'android_12': '31',
    'android_11': '30',
    'android_10': '29',
    'android_9': '28',
    'android_8.1': '27',
    'android_8.0': '26',
    'android_7.1': '25',
    'android_7.0': '24',
    'android_6.0': '23',
    'android_5.1': '22',
    'android_5.0': '21',
}

api_platform_dict = {
     '34': 'android_14',
     '33': 'android_13',
     '32': 'android_12L',
     '31': 'android_12',
     '30': 'android_11',
     '29': 'android_10',
     '28': 'android_9',
     '27': 'android_8.1',
     '26': 'android_8.0',
     '25': 'android_7.1',
     '24': 'android_7.0',
     '23': 'android_6.0',
     '22': 'android_5.1',
     '21': 'android_5.0'
}

'''for version in version_list:
    print(base_diff_url %  version)
'''
api_evolution = {
    'all':{
            'add':    'alldiffs_index_additions',
            'remove': 'alldiffs_index_removals',
            'change': 'alldiffs_index_changes'
    },
    'package':{
            'add':    'packages_index_additions',
            'remove': 'packages_index_removals',
            'change': 'packages_index_changes'
    },
    'class': {
            'add':    'classes_index_additions',
            'remove': 'classes_index_removals',
            'change': 'classes_index_changes'
    },
    'constructor': {
            'add':    'constructors_index_additions',
            'remove': 'constructors_index_removals',
            'change': 'constructors_index_changes'
    },
    'method': {
            'add':    'methods_index_additions',
            'remove': 'methods_index_removals',
            'change': 'methods_index_changes'
    },
    'field': {
            'add':    'fields_index_additions',
            'remove': 'fields_index_removals',
            'change': 'fields_index_changes'
    }
}


api_data = []
api_item = {
    "api_version": 1,
    "platform_version": 1,
    "api_info": {
        "provider": "",
        "name": "api_name",
        "type": "",
        "args": [
            {"arg": {
                     "name" : "name",
                     "type" : "type",
                     "desc" : "desc for arg"
                    }
             }
        ],
        "return_value":{
             "type": 1,
             "desc": "return desc"
        },
        "throw" : {
            "type": 1,
            "desc": "throw desc"
        },
        "desc": "desc",
        "see_also": {
            "info" : "see also",
            "url" : "url"
        }
    },
    "api_evolution_info": {
            "direction": 1,
            "reason": 1,
            "time": 2
    },
    "url":""
}


s = [
    {'args': [
        {'arg': {
            'name': 'a',
            'type': 'long',
            'desc': 'the argument whose absolute value is to be determined'
            }
        }],
    'return_value': {
            'type': 'long', 'desc': 'the absolute value of the argument, unless overflow occurs'
        },
    'throw': {
            'type': 'ArithmeticException', 'desc': 'if the argument is Long#MIN_VALUE'
        }
    },
    {'args': [
        {'arg':
             {'name': 'a',
              'type': 'int',
              'desc': 'the argument whose absolute value is to be determined'}
         }],
        'return_value': {
            'type': 'int',
            'desc': 'the absolute value of the argument, unless overflow occurs'
        },
     'throw': {'type': 'ArithmeticException',
               'desc': 'if the argument is Integer#MIN_VALUE'}
    }
]




def get_url_result(url):
    session = requests.session()
    header = {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:95.0) Gecko/20100101 Firefox/95.0',
        'Connection': 'close'
    }
    try:
        res = session.get(url, headers=header, verify=False)
    except:
        print('get url happens wrong')
    return res.content


'''
base_url = "https://developer.android.com"
#url = "https://baidu.com"
session = requests.session()
url = "https://developer.android.com/sdk/api_diff/34/changes"  # 等会要爬的url地址
header = {
    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:95.0) Gecko/20100101 Firefox/95.0',
    'Connection':'close'
}  # UA伪装
#res = requests.get(url=url, headers=header, verify=False)  # 发送请求
try:
    res = session.get(url, headers=header, verify=False)
except:
    res = session.get(url, headers=header, verify=False)

# print (res.url) 测试用的
#data = res.text  # 所有的数据赋值给data变量
#print (data)
soup = BeautifulSoup(res.content, 'html.parser')
print(soup.prettify())
#print(soup.find_all('frame'))
#print(type(soup.find_all('frame')))
print(type(soup.find_all(attrs={"name": "bottomleftframe"})))
#changeDetail = soup.find_all(attrs={"name": "bottomleftframe"})

#node_by_path = soup.select('html > body')[0]
#print(node_by_path)
#print(soup.frame)
'''

'''
print(soup.find_all('script'))
print(soup.find_all('div'))
print(soup.select('.top'))
'''

#print(soup.prettify())


'''
pattern = '<span class="title-content-title">(.*?)</span>'  # 正则匹配查询内容
data_last = re.findall(pattern, data)
for index, data_last_true in enumerate(data_last):
    print(index, data_last_true)
# print ("热搜如下：".format('title-content-title' in data,encoding='utf-8'))
'''
