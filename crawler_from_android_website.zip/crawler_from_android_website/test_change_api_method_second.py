
from bs4 import BeautifulSoup
import json
import get_api_data_from_android
import requests
import time




html = """

"""

def get_url_result(url):
    session = requests.session()
    header = {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:95.0) Gecko/20100101 Firefox/95.0',
        'Connection': 'close'
    }
    try:
        res = session.get(url, headers=header, verify=False)
        return res.content
    except:
        print('get url happens wrong')
        return None


def get_api_info_method(version, api_reference_url, evo_info, platform_info, api_origin_dict):
    print('begin get api info constructor')
    base_url = "https://developer.android.com"
    print(api_reference_url)
    api_list = []
    item_dict = {}
    html = get_url_result(api_reference_url)
    if html is None:
        return api_list
    soup = BeautifulSoup(html, 'html.parser')
    provider_info_labels = soup.find_all('table', attrs = {"class" : "jd-inheritance-table"})
    print(len(provider_info_labels))
    if len(provider_info_labels) == 0: # 部分网页不存在
        return api_list
    tr_provider_labels = provider_info_labels[0].find_all('tr')
    print("tr_provider_labels" ,len(tr_provider_labels))
    provider_dict = {"provider" : ""}
    if (len(tr_provider_labels) > 1):
        td_provider_labels = tr_provider_labels[1].find('td', attrs = {"class" : "jd-inheritance-class-cell"})#[1].get_text()
        td_provider = ""
        if (len(td_provider_labels) == 1):
            td_provider = td_provider_labels.get_text().replace('\n', '').strip()
        provider_dict = {"provider" : td_provider}#package class
    else:
        td_provider_labels = tr_provider_labels[0].find('td',attrs={"class": "jd-inheritance-class-cell"})  # [1].get_text()
        td_provider = ""
        if (len(td_provider_labels) == 1):
            td_provider = td_provider_labels.get_text().replace('\n', '').strip()
        provider_dict = {"provider": td_provider}  # package class
    print(provider_dict)
    print(api_origin_dict)
    see_also_list = []
    div_labels = soup.find_all('div')
    count = 0
    if div_labels:
        print("div_labels  ",  len(div_labels))
        for m in range(0, len(div_labels)):
            h3_label = div_labels[m].find('h3', attrs ={"class" : "api-name"})
            if h3_label:
                api_id_label = h3_label['id']
                #api_text = h3_label.get_text()
                if api_id_label  and (api_id_label.replace('%20', ' ') in api_origin_dict.keys()):
                #if api_field in api_origin_dict.keys():
                    api_id_label_text = api_id_label.replace('%20', ' ')
                    count = count + 1
                    evo_info["reason"] = api_origin_dict[api_id_label_text]["change_desc"]
                    api_item = {
                        "api_version": platform_info["api_version"],
                        "platform_version": platform_info["platform_version"],
                        "url": api_reference_url,
                        "api_evolution_info": evo_info,
                        "see_also" : see_also_list,
                        "desc" :""
                    }
                    api_item.update(provider_dict)
                    api_item.update({"name" : api_id_label_text})
                    p_labels = div_labels[m].find_all('p')
                    if p_labels:
                        print("p_labels len ", len(p_labels))
                        api_desc = ""
                        if(len(p_labels) > 0 and len(p_labels) < 15):
                            for t in range(0, len(p_labels)):
                                #print(p_labels[t].get_text())
                                if ((p_labels[t].get_text().replace('\n', '')) not in api_desc):
                                    api_desc += p_labels[t].get_text().replace('\n', '')
                            api_item.update({"desc" : api_desc})
                        #print("api_desc  ", api_desc)
                    see_also_labels = div_labels[m].find_all('div')
                    see_also_list = []



                    if see_also_labels and (len(see_also_labels) < 30):
                        print("see also labels -----------: ", len(see_also_labels))
                        #print("see also labels  ", len(see_also_labels))
                        for s in range(0, len(see_also_labels)):
                            if see_also_labels[s] and ("See also:" in (see_also_labels[s].get_text())):
                                #print("See also info " , see_also_labels[s].get_text())
                                see_also_item_labels = see_also_labels[s].find_all('a')
                                if see_also_item_labels:
                                    for r in range(0, len(see_also_item_labels)):
                                        see_also_item_name = see_also_item_labels[r].get_text()
                                        see_also_item_url = base_url + see_also_item_labels[r]['href']
                                        item_info = {
                                            "info": see_also_item_name,
                                            "url" : see_also_item_url
                                        }
                                        see_also_item = {"see_also" : item_info}
                                        see_also_list.append(see_also_item)
                                api_item.update({"see_also": see_also_list})

                    parent_item = h3_label.parent
                    print(parent_item)
                    table_labels = parent_item.find_all('table',  attrs = {"class" : "responsive"})
                    print('-----------------')
                    #print(table_labels)
                    #print(parent_item)
                    print('&&&&&&&&&&&&&&&  len table_labels: ', len(table_labels))
                    for i in range(0, len(table_labels)):
                        tr_labels = table_labels[i].find_all('tr')
                        print('******')
                        print(len(tr_labels))
                        if ('Parameters' == tr_labels[0].get_text()):
                            print('Parameters')
                            arg_list = []
                            for n in range(1, len(tr_labels)):
                                arg_item = {}
                                td_labels = tr_labels[n].find_all('td')
                                print('----')
                                arg_name = td_labels[0].get_text()
                                arg_type = td_labels[1].find('code').get_text()
                                arg_desc = td_labels[1].get_text()
                                print(arg_name)
                                print(arg_type)
                                arg_desc_withour_reline = arg_desc.replace('\n', '')
                                final_arg_desc = arg_desc_withour_reline.replace(arg_type + ':', "").strip()
                                print(final_arg_desc)
                                arg_item["name"] = arg_name
                                arg_item["type"] = arg_type
                                arg_item["desc"] = final_arg_desc
                                dict = {"arg": arg_item}
                                arg_list.append(dict)
                            args_dict = {"args": arg_list}
                            api_item.update(args_dict)
                        elif ('Returns' == tr_labels[0].get_text()):
                            return_dict = {}
                            td_labels = tr_labels[1].find_all('td')
                            return_type = td_labels[0].find('code').get_text()
                            return_desc = td_labels[1].get_text().replace('\n', '')
                            print('Returns')
                            print(return_type)
                            print(return_desc)
                            return_dict["type"] = return_type
                            return_dict["desc"] = return_desc
                            dict = {"return_value": return_dict}
                            api_item.update(dict)
                        elif ('Throws' == tr_labels[0].get_text()):
                            throw_list = []
                            for u in range(1, len(tr_labels)):
                                print('Throws')
                                throw_dict = {}
                                td_labels = tr_labels[u].find_all('td')
                                throw_type = td_labels[0].find('code').get_text()
                                throw_desc = td_labels[1].get_text()
                                throw_dict["type"] = throw_type
                                throw_dict["desc"] = throw_desc
                                throw_list.append(throw_dict)
                                dict = {"throw": throw_list}
                            api_item.update(dict)

                    item_dict = {"api_info" : api_item}
                    api_list.append(item_dict)
    print("count-----", count)
    return api_list



def get_api_info_constructor(version, api_reference_url, evo_info, platform_info, api_origin_dict):
    print('begin get api info constructor')
    base_url = "https://developer.android.com"
    print(api_reference_url)
    api_list = []
    item_dict = {}
    html = get_url_result(api_reference_url)
    if html is None:
        return api_list
    soup = BeautifulSoup(html, 'html.parser')
    provider_info_labels = soup.find_all('table', attrs = {"class" : "jd-inheritance-table"})
    print(len(provider_info_labels))
    if len(provider_info_labels) == 0: # 部分网页不存在
        return api_list
    tr_provider_labels = provider_info_labels[0].find_all('tr')
    print("tr_provider_labels" ,len(tr_provider_labels))
    provider_dict = {"provider" : ""}
    if (len(tr_provider_labels) > 1):
        td_provider_labels = tr_provider_labels[1].find('td', attrs = {"class" : "jd-inheritance-class-cell"})#[1].get_text()
        td_provider = ""
        if (len(td_provider_labels) == 1):
            td_provider = td_provider_labels.get_text().replace('\n', '').strip()
        provider_dict = {"provider" : td_provider}#package class
    else:
        td_provider_labels = tr_provider_labels[0].find('td',attrs={"class": "jd-inheritance-class-cell"})  # [1].get_text()
        td_provider = ""
        if (len(td_provider_labels) == 1):
            td_provider = td_provider_labels.get_text().replace('\n', '').strip()
        provider_dict = {"provider": td_provider}  # package class
    print(provider_dict)
    print(api_origin_dict)
    see_also_list = []
    div_labels = soup.find_all('div')
    count = 0
    if div_labels:
        print("div_labels  ",  len(div_labels))
        for m in range(0, len(div_labels)):
            h3_label = div_labels[m].find('h3', attrs ={"class" : "api-name"})
            if h3_label:
                api_id = h3_label['id']
                if api_id and (api_id.replace('%20', ' ')) in api_origin_dict.keys():
                #if api_field in api_origin_dict.keys():

                    count = count + 1
                    replace_api_id = api_id.replace('%20', ' ')
                    print("api_id---- ", api_id)
                    evo_info["reason"] = api_origin_dict[replace_api_id]["change_desc"]
                    api_item = {
                        "api_version": platform_info["api_version"],
                        "platform_version": platform_info["platform_version"],
                        "url": api_reference_url,
                        "api_evolution_info": evo_info,
                        "see_also" : see_also_list,
                        "desc" :""
                    }
                    api_item.update(provider_dict)
                    api_item.update({"name" : replace_api_id.split('(')[0]})
                    p_labels = div_labels[m].find_all('p')
                    if p_labels:
                        print("p_labels len ", len(p_labels))
                        api_desc = ""
                        if(len(p_labels) > 0 and len(p_labels) < 15):
                            for t in range(0, len(p_labels)):
                                #print(p_labels[t].get_text())
                                if ((p_labels[t].get_text().replace('\n', '')) not in api_desc):
                                    api_desc += p_labels[t].get_text().replace('\n', '')
                            api_item.update({"desc" : api_desc})
                        #print("api_desc  ", api_desc)
                    see_also_labels = div_labels[m].find_all('div')
                    see_also_list = []



                    if see_also_labels and (len(see_also_labels) < 30):
                        print("see also labels -----------: ", len(see_also_labels))
                        #print("see also labels  ", len(see_also_labels))
                        for s in range(0, len(see_also_labels)):
                            if see_also_labels[s] and ("See also:" in (see_also_labels[s].get_text())):
                                #print("See also info " , see_also_labels[s].get_text())
                                see_also_item_labels = see_also_labels[s].find_all('a')
                                if see_also_item_labels:
                                    for r in range(0, len(see_also_item_labels)):
                                        see_also_item_name = see_also_item_labels[r].get_text()
                                        see_also_item_url = base_url + see_also_item_labels[r]['href']
                                        item_info = {
                                            "info": see_also_item_name,
                                            "url" : see_also_item_url
                                        }
                                        see_also_item = {"see_also" : item_info}
                                        see_also_list.append(see_also_item)
                                api_item.update({"see_also": see_also_list})

                    parent_item = h3_label.parent
                    table_labels = parent_item.find_all('table',  attrs = {"class" : "responsive"})
                    print('-----------------')
                    #print(table_labels)
                    #print(parent_item)
                    for i in range(0, len(table_labels)):
                        tr_labels = table_labels[i].find_all('tr')
                        print('******')
                        print(len(tr_labels))
                        if ('Parameters' == tr_labels[0].get_text()):
                            print('Parameters')
                            arg_list = []
                            for n in range(1, len(tr_labels)):
                                arg_item = {}
                                td_labels = tr_labels[n].find_all('td')
                                print('----')
                                arg_name = td_labels[0].get_text()
                                arg_type = td_labels[1].find('code').get_text()
                                arg_desc = td_labels[1].get_text()
                                print(arg_name)
                                print(arg_type)
                                arg_desc_withour_reline = arg_desc.replace('\n', '')
                                final_arg_desc = arg_desc_withour_reline.replace(arg_type + ':', "").strip()
                                print(final_arg_desc)
                                arg_item["name"] = arg_name
                                arg_item["type"] = arg_type
                                arg_item["desc"] = final_arg_desc
                                dict = {"arg": arg_item}
                                arg_list.append(dict)
                            args_dict = {"args": arg_list}
                            api_item.update(args_dict)
                        elif ('Returns' == tr_labels[0].get_text()):
                            return_dict = {}
                            td_labels = tr_labels[1].find_all('td')
                            return_type = td_labels[0].find('code').get_text()
                            return_desc = td_labels[1].get_text().replace('\n', '')
                            print('Returns')
                            print(return_type)
                            print(return_desc)
                            return_dict["type"] = return_type
                            return_dict["desc"] = return_desc
                            dict = {"return_value": return_dict}
                            api_item.update(dict)
                        elif ('Throws' == tr_labels[0].get_text()):
                            throw_list = []
                            for u in range(1, len(tr_labels)):
                                print('Throws')
                                throw_dict = {}
                                td_labels = tr_labels[u].find_all('td')
                                throw_type = td_labels[0].find('code').get_text()
                                throw_desc = td_labels[1].get_text()
                                throw_dict["type"] = throw_type
                                throw_dict["desc"] = throw_desc
                                throw_list.append(throw_dict)
                                dict = {"throw": throw_list}
                            api_item.update(dict)

                    item_dict = {"api_info" : api_item}
                    api_list.append(item_dict)
    print("count-----", count)
    return api_list

def get_api_info_field(version, api_reference_url, evo_info, platform_info, api_origin_dict):
    print('begin get api info')
    base_url = "https://developer.android.com"
    print(api_reference_url)
    api_list = []
    item_dict = {}
    html = get_url_result(api_reference_url)
    if html is None:
        return api_list
    soup = BeautifulSoup(html, 'html.parser')
    provider_info_labels = soup.find_all('table', attrs = {"class" : "jd-inheritance-table"})
    print(len(provider_info_labels))
    if len(provider_info_labels) == 0: # 部分网页不存在
        return api_list
    tr_provider_labels = provider_info_labels[0].find_all('tr')
    print("tr_provider_labels" ,len(tr_provider_labels))
    provider_dict = {"provider" : ""}
    if (len(tr_provider_labels) > 1):
        td_provider_labels = tr_provider_labels[1].find('td', attrs = {"class" : "jd-inheritance-class-cell"})#[1].get_text()
        td_provider = ""
        if (len(td_provider_labels) == 1):
            td_provider = td_provider_labels.get_text().replace('\n', '').strip()
        provider_dict = {"provider" : td_provider}#package class
    else:
        td_provider_labels = tr_provider_labels[0].find('td',attrs={"class": "jd-inheritance-class-cell"})  # [1].get_text()
        td_provider = ""
        if (len(td_provider_labels) == 1):
            td_provider = td_provider_labels.get_text().replace('\n', '').strip()
        provider_dict = {"provider": td_provider}  # package class

    see_also_list = []
    div_labels = soup.find_all('div')
    count = 0
    if div_labels:
        print("div_labels  ",  len(div_labels))
        for m in range(0, len(div_labels)):
            h3_label = div_labels[m].find('h3', attrs ={"class" : "api-name"})
            if h3_label:
                api_field = h3_label.get_text()
                if api_field in api_origin_dict.keys():

                    count = count + 1

                    print("api_field---- ", api_field)
                    evo_info["reason"] = api_origin_dict[api_field]["change_desc"]
                    api_item = {
                        "api_version": platform_info["api_version"],
                        "platform_version": platform_info["platform_version"],
                        "url": api_reference_url,
                        "api_evolution_info": evo_info,
                        "see_also" : see_also_list,
                        "desc" :""
                    }
                    api_item.update(provider_dict)
                    api_item.update({"name" : api_field})
                    p_labels = div_labels[m].find_all('p')
                    if p_labels:
                        print("p_labels len ", len(p_labels))
                        api_desc = ""
                        if(len(p_labels) > 0 and len(p_labels) < 15):
                            for t in range(0, len(p_labels)):
                                #print(p_labels[t].get_text())
                                if ((p_labels[t].get_text().replace('\n', '')) not in api_desc):
                                    api_desc += p_labels[t].get_text().replace('\n', '')
                            api_item.update({"desc" : api_desc})
                        #print("api_desc  ", api_desc)
                    see_also_labels = div_labels[m].find_all('div')
                    see_also_list = []
                    if see_also_labels and (len(see_also_labels) < 30):
                        print("see also labels -----------: ", len(see_also_labels))
                        #print("see also labels  ", len(see_also_labels))
                        for s in range(0, len(see_also_labels)):
                            if see_also_labels[s] and ("See also:" in (see_also_labels[s].get_text())):
                                #print("See also info " , see_also_labels[s].get_text())
                                see_also_item_labels = see_also_labels[s].find_all('a')
                                if see_also_item_labels:
                                    for r in range(0, len(see_also_item_labels)):
                                        see_also_item_name = see_also_item_labels[r].get_text()
                                        see_also_item_url = base_url + see_also_item_labels[r]['href']
                                        item_info = {
                                            "info": see_also_item_name,
                                            "url" : see_also_item_url
                                        }
                                        see_also_item = {"see_also" : item_info}
                                        see_also_list.append(see_also_item)
                                api_item.update({"see_also": see_also_list})
                    item_dict = {"api_info" : api_item}
                    api_list.append(item_dict)
    print("count-----", count)
    return api_list

android_base_url = "https://developer.android.com"
api_url = "ttt"

def generate_evolution_info(target_version, evolution_time):
    for m in get_api_data_from_android.version_list:
        print(m)
    print(target_version - 1)
    from_version = str(target_version - 1)
    target_version = str(target_version)
    evolution_info = {
        "add_evolution_info" : {
                "from_version" : from_version,
                "to_version" : target_version,
                "direction": "added",
                "reason": "no",
                "time": evolution_time
        },
        "changed_evolution_info" : {
                 "from_version" : from_version,
                "to_version" : target_version,
                "direction": "change",
                "reason": "no",
                "time": evolution_time
        },
        "remove_evolution_info" : {
                "from_version" : from_version,
                "to_version" : target_version,
                "direction": "remove",
                "reason": "no",
                "time": evolution_time
        }
    }
    print(evolution_info)

def get_change_api_methods_reference_url(origin_url):
    class_base_reference_url = {}
    html = get_url_result(origin_url)
    if html is None:
        return []
    soup = BeautifulSoup(html, 'html.parser')
    reference_base_url = "https://developer.android.com/"
    remove_labels = soup.find_all('table', summary="Changed Methods")
    for i in range(0, len(remove_labels)):
        api_list = []
        class_reference_url = ""
        tr_labels = remove_labels[i].find_all('tr')
        print(len(tr_labels))
        class_detail_url_to_reference_item = {}
        for j in range(1, len(tr_labels)):
            api_item = {}
            reference_dict = {}
            a_labels = tr_labels[j].find_all('a')
            print(len(a_labels))
            if (len(a_labels) > 0):
                api_name_label = a_labels[0]['name']
                api_type_label = tr_labels[j].find('code')
                change_desc_label = tr_labels[j].find_all('td')

                url_href = a_labels[1]['href']
                api_href = url_href.replace('../', '')
                api_target_url = reference_base_url + api_href
                class_reference_url = api_target_url.split('#')[0]
                field_type = ""
                change_desc = ""
                if api_type_label:
                        if (len(api_type_label) > 0):
                            field_type = api_type_label.get_text()
                if change_desc_label:
                    if(len(change_desc_label) > 0):
                        print('-----------')
                        print(len(change_desc_label))
                        print(change_desc_label)
                        print('------------')
                        change_desc = change_desc_label[1].get_text()
                else:
                    change_desc = tr_labels[j].get_text()
                api_item = {
                    "api_url": api_target_url,
                    "api_name_label": api_name_label,
                    "field_type" : field_type,
                    "change_desc" : change_desc
                }
                reference_dict.update({"api_item" : api_item})
                api_list.append(reference_dict)
        class_detail_url_to_reference_item.update({
            "class_reference_url" : class_reference_url,
            "field_detail_to_reference" : api_list
        })
        #detail_url_to_reference_list.append(class_detail_url_to_reference_item)
        return class_detail_url_to_reference_item


def get_change_api_constructors_reference_url(origin_url):
    class_base_reference_url = {}
    html = get_url_result(origin_url)
    soup = BeautifulSoup(html, 'html.parser')
    reference_base_url = "https://developer.android.com/"
    remove_labels = soup.find_all('table', summary="Changed Constructors")
    for i in range(0, len(remove_labels)):
        api_list = []
        class_reference_url = ""
        tr_labels = remove_labels[i].find_all('tr')
        print(len(tr_labels))
        class_detail_url_to_reference_item = {}
        for j in range(1, len(tr_labels)):
            api_item = {}
            reference_dict = {}
            a_labels = tr_labels[j].find_all('a')
            print(len(a_labels))
            if (len(a_labels) > 0):
                api_name_label = a_labels[0]['name']
                api_type_label = tr_labels[j].find('code')
                change_desc_label = tr_labels[j].find('b')

                url_href = a_labels[1]['href']
                api_href = url_href.replace('../', '')
                api_target_url = reference_base_url + api_href
                class_reference_url = api_target_url.split('#')[0]
                field_type = ""
                change_desc = ""
                if api_type_label:
                        if (len(api_type_label) > 0):
                            field_type = api_type_label.get_text()
                if change_desc_label:
                    if(len(change_desc_label) > 0):
                        change_desc = change_desc_label.get_text()
                else:
                    change_desc = tr_labels[j].get_text()
                api_item = {
                    "api_url": api_target_url,
                    "api_name_label": api_name_label,
                    "field_type" : field_type,
                    "change_desc" : change_desc
                }
                reference_dict.update({"api_item" : api_item})
                api_list.append(reference_dict)
        class_detail_url_to_reference_item.update({
            "class_reference_url" : class_reference_url,
            "field_detail_to_reference" : api_list
        })
        #detail_url_to_reference_list.append(class_detail_url_to_reference_item)
        return class_detail_url_to_reference_item




def get_change_api_fields_reference_url(origin_url):
    class_base_reference_url = {}
    html = get_url_result(origin_url)
    soup = BeautifulSoup(html, 'html.parser')
    reference_base_url = "https://developer.android.com/"
    remove_labels = soup.find_all('table', summary="Changed Fields")
    for i in range(0, len(remove_labels)):
        api_list = []
        class_reference_url = ""
        tr_labels = remove_labels[i].find_all('tr')
        print(len(tr_labels))
        class_detail_url_to_reference_item = {}
        for j in range(1, len(tr_labels)):
            api_item = {}
            reference_dict = {}
            a_labels = tr_labels[j].find_all('a')
            print(len(a_labels))
            if (len(a_labels) > 0):
                api_name_label = a_labels[0]['name']
                api_type_label = tr_labels[j].find('code')
                change_desc_label = tr_labels[j].find('b')

                url_href = a_labels[1]['href']
                api_href = url_href.replace('../', '')
                api_target_url = reference_base_url + api_href
                class_reference_url = api_target_url.split('#')[0]
                field_type = ""
                change_desc = ""
                if api_type_label:
                        if (len(api_type_label) > 0):
                            field_type = api_type_label.get_text()
                if change_desc_label:
                    if(len(change_desc_label) > 0):
                        change_desc = change_desc_label.get_text()
                else:
                    change_desc = tr_labels[j].get_text()
                api_item = {
                    "api_url": api_target_url,
                    "api_name_label": api_name_label,
                    "field_type" : field_type,
                    "change_desc" : change_desc
                }
                reference_dict.update({"api_item" : api_item})
                api_list.append(reference_dict)
        class_detail_url_to_reference_item.update({
            "class_reference_url" : class_reference_url,
            "field_detail_to_reference" : api_list
        })
        #detail_url_to_reference_list.append(class_detail_url_to_reference_item)
        return class_detail_url_to_reference_item


def get_change_field_url_dict_data(origin_url):#first
    result = get_url_result(origin_url)
    soup = BeautifulSoup(result, 'html.parser')
    change_labels = soup.find_all('a', target="rightframe")
    target_add_urls_dict = {}
    for i in range(0, len(change_labels)):
        print('begin get url-----', i)
        url_href = change_labels[i]['href']
        api_target_url = android_base_url + url_href
        api_label = change_labels[i].get_text()
        #api = api_label.get_text()
        api_target_url_prefix = api_target_url.split('#')[0]
        target_add_urls_dict.update({api_target_url_prefix : api_target_url})
    return target_add_urls_dict

def get_change_method_url_dict_data(origin_url):#first
    result = get_url_result(origin_url)
    soup = BeautifulSoup(result, 'html.parser')
    change_labels = soup.find_all('a', target="rightframe")
    target_add_urls_dict = {}
    for i in range(0, len(change_labels)):
        print('begin get url-----', i)
        url_href = change_labels[i]['href']
        api_target_url = android_base_url + url_href
        api_label = change_labels[i].get_text()
        #api = api_label.get_text()
        api_target_url_prefix = api_target_url.split('#')[0]
        target_add_urls_dict.update({api_target_url_prefix : api_target_url})
    return target_add_urls_dict

def get_change_constructor_url_dict_data(origin_url):#first
    result = get_url_result(origin_url)
    soup = BeautifulSoup(result, 'html.parser')
    change_labels = soup.find_all('a', target="rightframe")
    target_add_urls_dict = {}
    for i in range(0, len(change_labels)):
        print('begin get url-----', i)
        url_href = change_labels[i]['href']
        api_target_url = android_base_url + url_href
        api_label = change_labels[i].get_text()
        #api = api_label.get_text()
        api_target_url_prefix = api_target_url.split('#')[0]
        target_add_urls_dict.update({api_target_url_prefix : api_target_url})
    return target_add_urls_dict


def get_remove_method_url_dict_data(origin_url):#first
    result = get_url_result(origin_url)
    soup = BeautifulSoup(result, 'html.parser')
    remove_labels = soup.find_all('a', target="rightframe")
    target_add_urls_dict = {}
    for i in range(0, len(remove_labels)):
        print('begin get url-----', i)
        url_href = remove_labels[i]['href']
        api_target_url = android_base_url + url_href
        api_label = remove_labels[i].get_text()
        #api = api_label.get_text()
        api_target_url_prefix = api_target_url.split('#')[0]
        target_add_urls_dict.update({api_target_url_prefix : api_target_url})
    return target_add_urls_dict


def get_add_method_url_dict_data(origin_url):#first
    result = get_url_result(origin_url)
    soup = BeautifulSoup(result, 'html.parser')
    add_labels = soup.find_all('a', target="rightframe")
    target_add_urls_dict = {}
    for i in range(0, len(add_labels)):
        print('begin get url-----', i)
        url_href = add_labels[i]['href']
        api_target_url = android_base_url + url_href
        api_label = add_labels[i].find('b')
        api = api_label.get_text()
        api_target_url_prefix = api_target_url.split('#')[0]
        target_add_urls_dict.update({api_target_url_prefix : api_target_url})
    return target_add_urls_dict

def get_add_field_url_dict_data(origin_url):#first
    result = get_url_result(origin_url)
    soup = BeautifulSoup(result, 'html.parser')
    add_labels = soup.find_all('a', target="rightframe")
    target_add_urls_dict = {}
    for i in range(0, len(add_labels)):
        print('begin get url-----', i)
        url_href = add_labels[i]['href']
        api_target_url = android_base_url + url_href
        api_label = add_labels[i].get_text()
        print(api_label)
        #api = api_label.get_text()
        api_target_url_prefix = api_target_url.split('#')[0]
        target_add_urls_dict.update({api_target_url_prefix : api_target_url})
    return target_add_urls_dict

def get_add_constructor_url_dict_data(origin_url):#first
    result = get_url_result(origin_url)
    soup = BeautifulSoup(result, 'html.parser')
    add_labels = soup.find_all('a', target="rightframe")
    target_add_urls_dict = {}
    for i in range(0, len(add_labels)):
        print('begin get url-----', i)
        url_href = add_labels[i]['href']
        api_target_url = android_base_url + url_href
        api_label = add_labels[i].find('b')
        api = api_label.get_text()
        api_target_url_prefix = api_target_url.split('#')[0]
        target_add_urls_dict.update({api_target_url_prefix : api_target_url})
    return target_add_urls_dict


def write_version_change_final_field_url_file(version, data):
    file = './evolution/final_data/field_change_' + str(version) + '_version' + '.json'
    with open(file, "w" ) as f:
        json.dump(data, f)

def write_version_change_final_method_url_file(version, data):
    file = './evolution/final_data/method_change_' + str(version) + '_version' + '.json'
    with open(file, "w" ) as f:
        json.dump(data, f)

def write_version_change_final_constructor_url_file(version, data):
    file = './evolution/final_data/constructor_change_' + str(version) + '_version' + '.json'
    with open(file, "w" ) as f:
        json.dump(data, f)

def write_version_remove_method_reference_url_file(version, data):
    file = './evolution/method_detail_to_reference_remove_' + str(version) + '_version' + '.json'
    with open(file, "w" ) as f:
        json.dump(data, f)

def write_version_remove_constructor_reference_url_file(version, data):
    file = './evolution/constructor_detail_to_reference_remove_' + str(version) + '_version' + '.json'
    with open(file, "w" ) as f:
        json.dump(data, f)

def write_version_remove_field_reference_url_file(version, data):
    file = './evolution/field_detail_to_reference_remove_' + str(version) + '_version' + '.json'
    with open(file, "w" ) as f:
        json.dump(data, f)


def write_version_change_method_reference_url_file(version, data):
    file = './evolution/method_detail_to_reference_change_' + str(version) + '_version' + '.json'
    with open(file, "w" ) as f:
        json.dump(data, f)

def write_version_change_constructor_reference_url_file(version, data):
    file = './evolution/constructor_detail_to_reference_change_' + str(version) + '_version' + '.json'
    with open(file, "w" ) as f:
        json.dump(data, f)

def write_version_change_field_reference_url_file(version, data):
    file = './evolution/field_detail_to_reference_change_' + str(version) + '_version' + '.json'
    with open(file, "w" ) as f:
        json.dump(data, f)

def get_version_change_method_reference_url_file(version):
    file = './evolution/method_detail_to_reference_change_' + str(version) + '_version' + '.json'
    with open(file, 'r', encoding='utf-8') as f:
        data = json.load(f)
        # print(data)
        return data

def get_version_change_constructor_reference_url_file(version):
    file = './evolution/constructor_detail_to_reference_change_' + str(version) + '_version' + '.json'
    with open(file, 'r', encoding='utf-8') as f:
        data = json.load(f)
        # print(data)
        return data

def get_version_change_field_reference_url_file(version):
    file = './evolution/field_detail_to_reference_change_' + str(version) + '_version' + '.json'
    with open(file, 'r', encoding='utf-8') as f:
        data = json.load(f)
        # print(data)
        return data


def write_version_remove_method_url_file(version, data):
    file = './evolution/method_remove_' + str(version) + '_version' + '.json'
    with open(file, "w" ) as f:
        json.dump(data, f)

def write_version_remove_constructor_url_file(version, data):
    file = './evolution/constructor_remove_' + str(version) + '_version' + '.json'
    with open(file, "w" ) as f:
        json.dump(data, f)

def write_version_remove_field_url_file(version, data):
    file = './evolution/field_remove_' + str(version) + '_version' + '.json'
    with open(file, "w" ) as f:
        json.dump(data, f)

def get_version_remove_method_data(version):
    file =  './evolution/method_remove_' + str(version) + '_version' + '.json'
    with open(file, 'r', encoding='utf-8') as f:
        data = json.load(f)
        #print(data)
        return data

def get_version_remove_constructor_data(version):
    file =  './evolution/constructor_remove_' + str(version) + '_version' + '.json'
    with open(file, 'r', encoding='utf-8') as f:
        data = json.load(f)
        #print(data)
        return data

def get_version_remove_field_data(version):
    file =  './evolution/field_remove_' + str(version) + '_version' + '.json'
    with open(file, 'r', encoding='utf-8') as f:
        data = json.load(f)
        #print(data)
        return data

def write_version_change_method_url_file(version, data):
    file = './evolution/method_change_' + str(version) + '_version' + '.json'
    with open(file, "w" ) as f:
        json.dump(data, f)

def write_version_change_constructor_url_file(version, data):
    file = './evolution/constructor_change_' + str(version) + '_version' + '.json'
    with open(file, "w" ) as f:
        json.dump(data, f)

def write_version_change_field_url_file(version, data):
    file = './evolution/field_change_' + str(version) + '_version' + '.json'
    with open(file, "w" ) as f:
        json.dump(data, f)

def get_version_change_method_data(version):
    file =  './evolution/method_change_' + str(version) + '_version' + '.json'
    with open(file, 'r', encoding='utf-8') as f:
        data = json.load(f)
        #print(data)
        return data

def get_version_change_constructor_data(version):
    file =  './evolution/constructor_change_' + str(version) + '_version' + '.json'
    with open(file, 'r', encoding='utf-8') as f:
        data = json.load(f)
        #print(data)
        return data

def get_version_change_field_data(version):
    file =  './evolution/field_change_' + str(version) + '_version' + '.json'
    with open(file, 'r', encoding='utf-8') as f:
        data = json.load(f)
        #print(data)
        return data



def write_version_add_method_url_file(version, data):
    file = './evolution/method_add_' + str(version) + '_version' + '.json'
    with open(file, "w" ) as f:
        json.dump(data, f)

def write_version_add_field_url_file(version, data):
    file = './evolution/field_add_' + str(version) + '_version' + '.json'
    with open(file, "w" ) as f:
        json.dump(data, f)

def write_version_add_constructor_url_file(version, data):
    file = './evolution/constructor_add_' + str(version) + '_version' + '.json'
    with open(file, "w" ) as f:
        json.dump(data, f)

def get_version_add_method_data(version):
    file =  './evolution/method_add_' + str(version) + '_version' + '.json'
    with open(file, 'r', encoding='utf-8') as f:
        data = json.load(f)
        #print(data)
        return data

def get_version_add_field_data(version):
    file =  './evolution/field_add_' + str(version) + '_version' + '.json'
    with open(file, 'r', encoding='utf-8') as f:
        data = json.load(f)
        #print(data)
        return data

def get_version_add_constructor_data(version):
    file =  './evolution/constructor_add_' + str(version) + '_version' + '.json'
    with open(file, 'r', encoding='utf-8') as f:
        data = json.load(f)
        #print(data)
        return data

detail_url_to_reference_list = {}
def get_add_method_detail_url_to_reference_data(origin_url):#second
    reference_base_url = "https://developer.android.com/"
    html = get_url_result(origin_url)
    soup = BeautifulSoup(html, 'html.parser')
    add_labels = soup.find_all('table', summary="Added Methods")
    for i in range(0, len(add_labels)):
        tr_labels = add_labels[i].find_all('tr')
        print(len(tr_labels))
        for j in range(1, len(tr_labels)):
            a_labels = tr_labels[j].find_all('a')
            if (len(a_labels) > 0):
                api_name_label = a_labels[0]['name']
                api_href = a_labels[1]['href'].replace('../', '')
                api_url = reference_base_url + api_href
                print(api_name_label)
                print(api_url)


def get_constructor_reference_add_data(version):
    file = './evolution/constructor_detail_to_reference_add_' + str(version) + '_version' + '.json'
    print(file)
    with open(file, 'r', encoding='utf-8') as f:
        data = json.load(f)
        #print(data)
        return data

def get_field_reference_add_data(version):
    file = './evolution/field_detail_to_reference_add_' + str(version) + '_version' + '.json'
    print(file)
    with open(file, 'r', encoding='utf-8') as f:
        data = json.load(f)
        #print(data)
        return data

def get_method_reference_add_data(version):
    file = './evolution/method_detail_to_reference_add_' + str(version) + '_version' + '.json'
    print(file)
    with open(file, 'r', encoding='utf-8') as f:
        data = json.load(f)
        #print(data)
        return data

#ToDo 将evolution文件中的数据，继续爬取url，获取具体的api数据存储起来

direction = "change" # "remove", "change"
target_version = 23
#method_change_url =get_api_data_from_android.base_diff_url % str(target_version) + get_api_data_from_android.api_evolution['method'][direction]
#field_change_url =get_api_data_from_android.base_diff_url % str(target_version) + get_api_data_from_android.api_evolution['field'][direction]
#constructor_change_url =get_api_data_from_android.base_diff_url % str(target_version) + get_api_data_from_android.api_evolution['constructor'][direction]

#method_change_url =get_api_data_from_android.base_diff_url % str(target_version) + get_api_data_from_android.api_evolution['method'][direction]
constructor_change_url =get_api_data_from_android.base_diff_url % str(target_version) + get_api_data_from_android.api_evolution['constructor'][direction]
#field_change_url =get_api_data_from_android.base_diff_url % str(target_version) + get_api_data_from_android.api_evolution['field'][direction]


evolution_time = get_api_data_from_android.evolution_time_dict[str(target_version)]
platform_version = get_api_data_from_android.api_platform_dict[str(target_version)]
print(constructor_change_url)
print(evolution_time)

evolution_info = {
    "direction": "change",
    "reason": "",
    "time": evolution_time
}

platform_info = {
    "api_version" : target_version,
    "platform_version" : platform_version
}

'''
list_data = get_version_change_method_reference_url_file(target_version)
print(len(list_data))
final_to_write_list = []
for m in range(0, len(list_data)):
    #print(list_data[m])
    if list_data[m]:
        class_reference_url = list_data[m]["class_reference_url"]
        #if class_reference_url == "https://developer.android.com/reference/android/app/Notification.Action.Builder.html":
        method_detail_to_reference_list = list_data[m]["field_detail_to_reference"]
        print("constructor_detail_to_reference_list, " , len(method_detail_to_reference_list))
        api_name_dict = {}
        for n in range(0, len(method_detail_to_reference_list)):
            api_dict = {}
            api_name = method_detail_to_reference_list[n]['api_item']['api_name_label'].split('_changed')[0]
            api_name_abbreviation = method_detail_to_reference_list[n]['api_item']['api_url'].split('#')[1]
            change_desc = method_detail_to_reference_list[n]['api_item']['change_desc']
            field_type = method_detail_to_reference_list[n]['api_item']['field_type']
            #api_full_name = api_name.split('field_type')[0] +

            api_detail_dict = {
                "api_name" : api_name,
                "change_desc" : change_desc,
                "field_type" : field_type
            }

            api_name_dict.update({api_name_abbreviation : api_detail_dict})
        #print("api_name_dict, ", len(api_name_dict))
        #print(api_name_dict.keys())
        print(api_name_dict)
        #print('-------')
        #print(api_name_dict)
        #class_reference_url = "https://developer.android.com/reference/android/media/MediaCodecInfo.CodecCapabilities"
        result_list = get_api_info_method(target_version, class_reference_url, evolution_info, platform_info, api_name_dict)
        for q in range(0, len(result_list)):
            final_to_write_list.append(result_list[q])

write_version_change_final_method_url_file(target_version, final_to_write_list)

'''


list_data = get_version_change_constructor_reference_url_file(target_version)
print(list_data)
print(len(list_data))
final_to_write_list = []
for m in range(0, len(list_data)):
    #print(list_data[m])
    if list_data[m]:
        class_reference_url = list_data[m]["class_reference_url"]
        #if class_reference_url == "https://developer.android.com/reference/android/app/Notification.Action.Builder.html":
        constructor_detail_to_reference_list = list_data[m]["field_detail_to_reference"]
        print("constructor_detail_to_reference_list, " , len(constructor_detail_to_reference_list))
        api_name_dict = {}
        for n in range(0, len(constructor_detail_to_reference_list)):
            api_dict = {}
            api_name = constructor_detail_to_reference_list[n]['api_item']['api_name_label'].split('ctor')
            api_name_abbreviation = constructor_detail_to_reference_list[n]['api_item']['api_url'].split('#')[1]
            change_desc = constructor_detail_to_reference_list[n]['api_item']['change_desc']
            field_type = constructor_detail_to_reference_list[n]['api_item']['field_type']
            #api_full_name = api_name.split('field_type')[0] +
            api_params = api_name_abbreviation.split('(')[1]
            new_short_api_name = field_type
            new_short_api_name_list = field_type.split('.')
            if len(new_short_api_name_list) > 0:
                print(len(new_short_api_name_list))
                new_short_api_name = new_short_api_name_list[len(new_short_api_name_list) - 1]
                print(new_short_api_name)
            new_short_api_name = new_short_api_name + '(' + api_params

            api_detail_dict = {
                "api_name" : api_name,
                "change_desc" : change_desc,
                "field_type" : field_type
            }

            api_name_dict.update({new_short_api_name : api_detail_dict})
        print("api_name_dict, ", len(api_name_dict))
        print(api_name_dict.keys())
        print(api_name_dict)
        #print('-------')
        #print(api_name_dict)
        #class_reference_url = "https://developer.android.com/reference/android/media/MediaCodecInfo.CodecCapabilities"
        result_list = get_api_info_constructor(target_version, class_reference_url, evolution_info, platform_info, api_name_dict)
        for q in range(0, len(result_list)):
            final_to_write_list.append(result_list[q])

write_version_change_final_constructor_url_file(target_version, final_to_write_list)



'''list_data = get_version_change_field_reference_url_file(target_version)
print(len(list_data))
final_to_write_list = []
for m in range(0, len(list_data)):
    #print(list_data[m])
    if list_data[m]:
        class_reference_url = list_data[m]["class_reference_url"]
        #if class_reference_url == "https://developer.android.com/reference/android/media/MediaCodecInfo.CodecCapabilities.html":
        field_detail_to_reference_list = list_data[m]["field_detail_to_reference"]
        print("field_detail_to_reference_list, " , len(field_detail_to_reference_list))
        api_name_dict = {}
        for n in range(0, len(field_detail_to_reference_list)):
            api_dict = {}
            api_name = field_detail_to_reference_list[n]['api_item']['api_name_label']
            api_name_abbreviation = field_detail_to_reference_list[n]['api_item']['api_url'].split('#')[1]
            change_desc = field_detail_to_reference_list[n]['api_item']['change_desc']
            field_type = field_detail_to_reference_list[n]['api_item']['field_type']
            api_detail_dict = {
                "api_name" : api_name,
                "change_desc" : change_desc,
                "field_type" : field_type
            }
            api_name_dict.update({api_name_abbreviation : api_detail_dict})
        print("api_name_dict, ", len(api_name_dict))
        print(api_name_dict.keys())
        #print('-------')
        #print(api_name_dict)
        #class_reference_url = "https://developer.android.com/reference/android/media/MediaCodecInfo.CodecCapabilities"
        result_list = get_api_info_field(target_version, class_reference_url, evolution_info, platform_info, api_name_dict)
        for q in range(0, len(result_list)):
            final_to_write_list.append(result_list[q])

write_version_change_final_field_url_file(target_version, final_to_write_list)
'''




'''
dict_data = get_version_change_method_data(target_version)
final_reference_list = []
for key, value in dict_data.items():
    time.sleep(3)
    print(key)
    item = get_change_api_methods_reference_url(key)
    final_reference_list.append(item)
write_version_change_method_reference_url_file(target_version, final_reference_list)
'''
'''
result_data = get_change_constructor_url_dict_data(constructor_change_url)
print(result_data)
write_version_change_constructor_url_file(target_version, result_data)
'''
#result = get_url_result("https://developer.android.com/sdk/api_diff/23/changes/android.content.res.ColorStateList")
#print(result)
'''for key, item in data_dict.items():
    time.sleep(3)
    print(key)
    item = get_remove_api_constructors_reference_url(key)
    reference_detail_list.append(item)
    print(item)
write_version_remove_constructor_reference_url_file(target_version, reference_detail_list)
    #print(result[m])

'''
'''
url = get_api_data_from_android.base_diff_url % str(target_version) + get_api_data_from_android.api_evolution['field'][direction]
result_data = get_remove_method_url_dict_data(url)
write_version_remove_field_url_file(target_version, result_data)
'''
'''
for t in range(22, 35):
    time.sleep(3)
    url = get_api_data_from_android.base_diff_url % str(t) + get_api_data_from_android.api_evolution['field'][direction]
    #print(url)
    result_data = get_remove_method_url_dict_data(url)
    print(result_data)
    write_version_remove_field_url_file(t, result_data)

'''

'''
把如下界面html数据中对应的url写入词典，此为 method add 的url
view-source:https://developer.android.com/sdk/api_diff/34/changes/methods_index_additions
'''

#https://developer.android.com/reference/java/lang/Math#absExact(int)
'''
dict_data = get_version_add_method_data(target_version)
for key, value in dict_data.items():
    print(key)
    print(value)
print(len(dict_data))
print(type(dict_data))
'''
'''
已完成所有版本 add method url 数据
'''
#dict_data = get_add_method_url_dict_data(method_change_url)
#write_version_add_method_url_file(target_version, dict_data)

#dict_data = get_add_field_url_dict_data(field_change_url)
#write_version_add_field_url_file(target_version, dict_data)

#dict_data = get_add_constructor_url_dict_data(constructor_change_url)
#write_version_add_constructor_url_file(target_version, dict_data)



def write_constructor_add_evolution_data(target_version, data):
    file = './evolution/final_data/constructor_add_' + str(target_version)+ '_version' + '.json'
    with open(file, "w") as f:
        json.dump(data, f)

def write_method_add_evolution_data(target_version, data):
    file = './evolution/final_data/method_add_' + str(target_version)+ '_version' + '.json'
    with open(file, "w") as f:
        json.dump(data, f)

def write_field_add_evolution_data(target_version, data):
    file = './evolution/final_data/field_add_' + str(target_version)+ '_version' + '.json'
    with open(file, "w") as f:
        json.dump(data, f)


#evolution_info = generate_evolution_info(target_version, evolution_time)
#print(get_api_data_from_android.version_list)
#get_api_info("34", android_base_url, api_url, evolution_info, android_info)
#api_url = "https://developer.android.com/reference/android/media/tv/AdRequest.html#AdRequest(int,%20int,%20android.net.Uri,%20long,%20long,%20long,%20android.os.Bundle)"


'''
add_type = "constructor" #, field, method
constructor_reference_dict_data = get_constructor_reference_add_data(target_version)
print(len(constructor_reference_dict_data))
final_api_evolution_list = []
for n in range(0, len(constructor_reference_dict_data)):
    api_name_dict = {}
    reference_url = constructor_reference_dict_data[n]['class_reference_url']
    api_name_list = constructor_reference_dict_data[n]['constructor_detail_to_reference']
    print(len(api_name_list))
    for m in range(0, len(api_name_list)):
        api_name = api_name_list[m]['api_item']['api_url'].split('#')[1].split('(')[0]
        api_name_dict.update({api_name_list[m]['api_item']['api_name_label'] : api_name})
    print(api_name_dict.values())
    print(type(api_name_dict.values()))
    print(reference_url)
    result = get_api_info(str(target_version), android_base_url, reference_url, evolution_info, platform_info)
    for x in range(0, len(result)):
        final_api_evolution_list.append(result[x])
write_constructor_add_evolution_data(target_version ,final_api_evolution_list)
'''

'''
xxx = get_url_result("https://developer.android.com/reference/android/service/voice/AlwaysOnHotwordDetector")
yyy = BeautifulSoup(xxx, 'html.parser')
print(yyy)
'''


'''
add_type = "method" #, field, method
method_reference_dict_data = get_method_reference_add_data(target_version)
print(len(method_reference_dict_data))
final_api_evolution_list = []
for n in range(0, len(method_reference_dict_data)):
    api_name_dict = {}
    print(n)
    if (method_reference_dict_data[n]):
        reference_url = method_reference_dict_data[n]['class_reference_url']
        api_name_list = method_reference_dict_data[n]['method_detail_to_reference']
        print(len(api_name_list))
        for m in range(0, len(api_name_list)):
            api_name = api_name_list[m]['api_item']['api_url'].split('#')[1].split('(')[0]
            api_name_dict.update({api_name_list[m]['api_item']['api_name_label'] : api_name})
        print(api_name_dict.values())
        print(type(api_name_dict.values()))
        print(reference_url)
        result = get_api_info(str(target_version), android_base_url, reference_url, evolution_info, platform_info)
        for x in range(0, len(result)):
            final_api_evolution_list.append(result[x])

write_method_add_evolution_data(target_version ,final_api_evolution_list)'''


'''
add_type = "field" #, field, method
field_reference_dict_data = get_field_reference_add_data(target_version)
print(len(field_reference_dict_data))
final_api_evolution_list = []
for n in range(0, len(field_reference_dict_data)):
    api_name_dict = {}
    print(n)
    if (field_reference_dict_data[n]):
        reference_url = field_reference_dict_data[n]['class_reference_url']
        api_name_list = field_reference_dict_data[n]['field_detail_to_reference']
        print(len(api_name_list))
        for m in range(0, len(api_name_list)):
            api_name = api_name_list[m]['api_item']['api_url'].split('#')[1].split('(')[0]
            api_name_dict.update({api_name_list[m]['api_item']['api_name_label'] : api_name})
        print(api_name_dict.values())
        print(type(api_name_dict.values()))
        print(reference_url)
        result = get_api_info(str(target_version), android_base_url, reference_url, evolution_info, platform_info)
        for x in range(0, len(result)):
            final_api_evolution_list.append(result[x])

write_field_add_evolution_data(target_version ,final_api_evolution_list)
'''


