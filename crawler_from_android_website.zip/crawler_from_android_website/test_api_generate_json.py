
from bs4 import BeautifulSoup
import json
import get_api_data_from_android
import requests
import time




html = """

"""

def get_url_result(url):
    session = requests.session()
    header = {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:95.0) Gecko/20100101 Firefox/95.0',
        'Connection': 'close'
    }
    try:
        res = session.get(url, headers=header, verify=False)
        return res.content
    except:
        print('get url happens wrong')
        return None




def get_api_info(version, base_url, api_reference_url, evo_info, platform_info):
    print('begin get api info')
    print(api_reference_url)
    api_list = []
    item_dict = {}
    html = get_url_result(api_reference_url)
    if html is None:
        return api_list
    soup = BeautifulSoup(html, 'html.parser')
    provider_info_labels = soup.find_all('table', attrs = {"class" : "jd-inheritance-table"})
    print(len(provider_info_labels))
    if len(provider_info_labels) == 0: # 部分网页不存在
        return api_list
    tr_provider_labels = provider_info_labels[0].find_all('tr')
    print(len(tr_provider_labels))
    provider_dict = {"provider" : ""}
    if (len(tr_provider_labels) > 1):
        td_provider_labels = tr_provider_labels[1].find('td', attrs = {"class" : "jd-inheritance-class-cell"})#[1].get_text()
        td_provider = ""
        if (len(td_provider_labels) == 1):
            td_provider = td_provider_labels.get_text().replace('\n', '').strip()
        provider_dict = {"provider" : td_provider}#package class
    else:
        td_provider_labels = tr_provider_labels[0].find('td',attrs={"class": "jd-inheritance-class-cell"})  # [1].get_text()
        td_provider = ""
        if (len(td_provider_labels) == 1):
            td_provider = td_provider_labels.get_text().replace('\n', '').strip()
        provider_dict = {"provider": td_provider}  # package class

    print(provider_dict)
    labels = soup.find_all('div', attrs = {"data-version-added" : version})
    for y in range(0, len(labels)):
        api_item = {
            "api_version": platform_info["api_version"],
            "platform_version": platform_info["platform_version"],
            "url": api_reference_url,
            "api_evolution_info": evo_info
        }
        api_item.update(provider_dict)
        #api_item.update({"url" : api_reference_url})
        api_name_label = labels[y].find('h3', attrs = {"class" : "api-name"})
        api_name = ""
        if (len(api_name_label) > 0):
            api_name = api_name_label['data-text']
        api_name_dict = {"name" : api_name}
        api_item.update(api_name_dict)
        api_tables_labels = labels[y].find_all('table', attrs= {'class':"responsive"})
        p_desc_labels = labels[y].find_all('p')
        print('%%%%%%%%%%%%%%%')
        print(len(p_desc_labels))
        api_desc = ''
        for m in range(0, len(p_desc_labels)):
            desc = p_desc_labels[m].get_text()
            print(desc)
            print('##############')
            api_desc = api_desc + desc
        api_desc = api_desc.replace('\n', '')
        desc = {"desc" : api_desc}
        #print(desc)
        print('&&&&&&&&&&&&&&&&&&&&&&&')
        api_item.update(desc)

        see_also_labels = labels[y].find_all('ul')
        if(len(see_also_labels) > 0):
            #print(see_also_labels[0].find('a')['href'])
            if(see_also_labels[0].find('a')):
                origin_see_also_info = see_also_labels[0].find('a')['href']
                see_also_info_url = base_url + origin_see_also_info
                print(see_also_info_url)
                final_see_also_info = origin_see_also_info.replace('/reference/', '').replace('#', '.').replace('/', '.')
                print(final_see_also_info)
                info_dict = {"info" : final_see_also_info, "url": see_also_info_url}
                see_also_info_dict = {"see_also" : info_dict}
                api_item.update(see_also_info_dict)
            else:
                info_dict = {"info": "no see also info", "url": "no exist"}
                see_also_info_dict = {"see_also": info_dict}
                api_item.update(see_also_info_dict)
        arg_list = []
        args_dict = {"args": arg_list}
        api_item.update(args_dict)

        return_dict = {}
        dict = {"return_value": return_dict}
        api_item.update(dict)

        throw_dict = {}
        dict = {"throw": throw_dict}
        api_item.update(dict)

        for i in range(0, len(api_tables_labels)):
            tr_labels = api_tables_labels[i].find_all('tr')
            print('******')
            print(len(tr_labels))
            if ('Parameters' == tr_labels[0].get_text()):
                print('Parameters')
                arg_list = []
                for n in range(1, len(tr_labels)):
                    arg_item = {}
                    td_labels = tr_labels[n].find_all('td')
                    print('----')
                    arg_name = td_labels[0].get_text()
                    arg_type = td_labels[1].find('code').get_text()
                    arg_desc = td_labels[1].get_text()
                    print(arg_name)
                    print(arg_type)
                    arg_desc_withour_reline = arg_desc.replace('\n', '')
                    final_arg_desc = arg_desc_withour_reline.replace(arg_type + ':', "").strip()
                    print(final_arg_desc)
                    arg_item["name"] = arg_name
                    arg_item["type"] = arg_type
                    arg_item["desc"] = final_arg_desc
                    dict = {"arg" : arg_item}
                    arg_list.append(dict)
                args_dict = {"args" : arg_list}
                api_item.update(args_dict)
            elif ('Returns' == tr_labels[0].get_text()):
                return_dict = {}
                td_labels = tr_labels[1].find_all('td')
                return_type = td_labels[0].find('code').get_text()
                return_desc = td_labels[1].get_text().replace('\n', '')
                print('Returns')
                print(return_type)
                print(return_desc)
                return_dict["type"] = return_type
                return_dict["desc"] = return_desc
                dict = {"return_value" : return_dict}
                api_item.update(dict)
            elif ('Throws' == tr_labels[0].get_text()):
                throw_list = []
                for u in range(1, len(tr_labels)):

                    print('Throws')
                    throw_dict = {}
                    td_labels = tr_labels[u].find_all('td')
                    throw_type = td_labels[0].find('code').get_text()
                    throw_desc = td_labels[1].get_text()
                    throw_dict["type"] = throw_type
                    throw_dict["desc"] = throw_desc
                    throw_list.append(throw_dict)
                    dict = {"throw": throw_list}
                api_item.update(dict)
        item_dict = {"api_info" : api_item}
        api_list.append(item_dict)
    return api_list


def get_api_info_field(version, base_url, api_reference_url, evo_info, platform_info, origin_api_dict):
    print('begin get api info field')
    print(api_reference_url)
    api_list = []
    item_dict = {}
    html = get_url_result(api_reference_url)
    if html is None:
        return api_list
    soup = BeautifulSoup(html, 'html.parser')
    provider_info_labels = soup.find_all('table', attrs = {"class" : "jd-inheritance-table"})
    print(len(provider_info_labels))
    if len(provider_info_labels) == 0: # 部分网页不存在
        return api_list
    tr_provider_labels = provider_info_labels[0].find_all('tr')
    print(len(tr_provider_labels))
    provider_dict = {"provider" : ""}
    if (len(tr_provider_labels) > 1):
        td_provider_labels = tr_provider_labels[1].find('td', attrs = {"class" : "jd-inheritance-class-cell"})#[1].get_text()
        td_provider = ""
        if (len(td_provider_labels) == 1):
            td_provider = td_provider_labels.get_text().replace('\n', '').strip()
        provider_dict = {"provider" : td_provider}#package class
    else:
        td_provider_labels = tr_provider_labels[0].find('td',attrs={"class": "jd-inheritance-class-cell"})  # [1].get_text()
        td_provider = ""
        if (len(td_provider_labels) == 1):
            td_provider = td_provider_labels.get_text().replace('\n', '').strip()
        provider_dict = {"provider": td_provider}  # package class

    print(provider_dict)
    labels = soup.find_all('div', attrs = {"data-version-added" : version})
    for y in range(0, len(labels)):
        api_name_label = labels[y].find('h3', attrs = {"class" : "api-name"})
        api_name_label_id_text = ""
        if api_name_label and api_name_label['id']:
            api_name_label_id_text = api_name_label['id'].replace('%20', ' ')
        if api_name_label_id_text in origin_api_dict.keys():

            api_item = {
                "api_version": platform_info["api_version"],
                "platform_version": platform_info["platform_version"],
                "url": api_reference_url,
                "api_evolution_info": evo_info
            }
            api_item.update(provider_dict)
            #api_item.update({"url" : api_reference_url})

            api_name = ""
            if (len(api_name_label) > 0):
                api_name = api_name_label['data-text']
            api_name_dict = {"name" : api_name}
            api_item.update(api_name_dict)
            api_tables_labels = labels[y].find_all('table', attrs= {'class':"responsive"})
            p_desc_labels = labels[y].find_all('p')
            print('%%%%%%%%%%%%%%%')
            print(len(p_desc_labels))
            api_desc = ''
            for m in range(0, len(p_desc_labels)):
                desc = p_desc_labels[m].get_text().replace('\n', '')
                print(desc)
                print('##############')
                if desc not in api_desc:
                    api_desc +=  desc
            api_desc = api_desc.replace('\n', '')
            desc = {"desc" : api_desc}
            #print(desc)
            print('&&&&&&&&&&&&&&&&&&&&&&&')
            api_item.update(desc)

            see_also_labels = labels[y].find_all('ul')
            see_also_list = []
            api_item.update({"see_also": see_also_list})
            if(len(see_also_labels) > 0):
                #print(see_also_labels[0].find('a')['href'])
                for z in range(0, len(see_also_labels)):
                    if(see_also_labels[z]):
                        see_also_item_labels = see_also_labels[z].find_all('a')
                        if see_also_item_labels:
                            for r in range(0, len(see_also_item_labels)):
                                see_also_item_name = see_also_item_labels[r].get_text()
                                see_also_item_url = base_url + see_also_item_labels[r]['href']
                                item_info = {
                                    "info": see_also_item_name,
                                    "url": see_also_item_url
                                }
                                see_also_item = {"see_also": item_info}
                                see_also_list.append(see_also_item)
                        api_item.update({"see_also" :see_also_list})


            arg_list = []
            args_dict = {"args": arg_list}
            api_item.update(args_dict)

            return_dict = {}
            dict = {"return_value": return_dict}
            api_item.update(dict)

            throw_dict = {}
            dict = {"throw": throw_dict}
            api_item.update(dict)

            for i in range(0, len(api_tables_labels)):
                tr_labels = api_tables_labels[i].find_all('tr')
                print('******')
                print(len(tr_labels))
                if ('Parameters' == tr_labels[0].get_text()):
                    print('Parameters')
                    arg_list = []
                    for n in range(1, len(tr_labels)):
                        arg_item = {}
                        td_labels = tr_labels[n].find_all('td')
                        print('----')
                        arg_name = td_labels[0].get_text()
                        arg_type = td_labels[1].find('code').get_text()
                        arg_desc = td_labels[1].get_text()
                        print(arg_name)
                        print(arg_type)
                        arg_desc_withour_reline = arg_desc.replace('\n', '')
                        final_arg_desc = arg_desc_withour_reline.replace(arg_type + ':', "").strip()
                        print(final_arg_desc)
                        arg_item["name"] = arg_name
                        arg_item["type"] = arg_type
                        arg_item["desc"] = final_arg_desc
                        dict = {"arg" : arg_item}
                        arg_list.append(dict)
                    args_dict = {"args" : arg_list}
                    api_item.update(args_dict)
                elif ('Returns' == tr_labels[0].get_text()):
                    return_dict = {}
                    td_labels = tr_labels[1].find_all('td')
                    return_type = td_labels[0].find('code').get_text()
                    return_desc = td_labels[1].get_text().replace('\n', '')
                    print('Returns')
                    print(return_type)
                    print(return_desc)
                    return_dict["type"] = return_type
                    return_dict["desc"] = return_desc
                    dict = {"return_value" : return_dict}
                    api_item.update(dict)
                elif ('Throws' == tr_labels[0].get_text()):
                    throw_list = []
                    for u in range(1, len(tr_labels)):

                        print('Throws')
                        throw_dict = {}
                        td_labels = tr_labels[u].find_all('td')
                        throw_type = td_labels[0].find('code').get_text()
                        throw_desc = td_labels[1].get_text()
                        throw_dict["type"] = throw_type
                        throw_dict["desc"] = throw_desc
                        throw_list.append(throw_dict)
                        dict = {"throw": throw_list}
                    api_item.update(dict)
            item_dict = {"api_info" : api_item}
            api_list.append(item_dict)
    return api_list



def get_api_info_constructor(version, base_url, api_reference_url, evo_info, platform_info, origin_api_dict):
    print('begin get api info constructor')
    print(api_reference_url)
    api_list = []
    item_dict = {}
    html = get_url_result(api_reference_url)
    if html is None:
        return api_list
    soup = BeautifulSoup(html, 'html.parser')
    provider_info_labels = soup.find_all('table', attrs = {"class" : "jd-inheritance-table"})
    print(len(provider_info_labels))
    if len(provider_info_labels) == 0: # 部分网页不存在
        return api_list
    tr_provider_labels = provider_info_labels[0].find_all('tr')
    print(len(tr_provider_labels))
    provider_dict = {"provider" : ""}
    if (len(tr_provider_labels) > 1):
        td_provider_labels = tr_provider_labels[1].find('td', attrs = {"class" : "jd-inheritance-class-cell"})#[1].get_text()
        td_provider = ""
        if (len(td_provider_labels) == 1):
            td_provider = td_provider_labels.get_text().replace('\n', '').strip()
        provider_dict = {"provider" : td_provider}#package class
    else:
        td_provider_labels = tr_provider_labels[0].find('td',attrs={"class": "jd-inheritance-class-cell"})  # [1].get_text()
        td_provider = ""
        if (len(td_provider_labels) == 1):
            td_provider = td_provider_labels.get_text().replace('\n', '').strip()
        provider_dict = {"provider": td_provider}  # package class

    print(provider_dict)
    labels = soup.find_all('div', attrs = {"data-version-added" : version})
    for y in range(0, len(labels)):
        api_name_label = labels[y].find('h3', attrs = {"class" : "api-name"})
        api_name_label_id_text = ""
        if api_name_label and api_name_label['id']:
            api_name_label_id_text = api_name_label.get_text()
        if api_name_label_id_text in origin_api_dict.keys():

            api_item = {
                "api_version": platform_info["api_version"],
                "platform_version": platform_info["platform_version"],
                "url": api_reference_url,
                "api_evolution_info": evo_info
            }
            api_item.update(provider_dict)
            #api_item.update({"url" : api_reference_url})

            api_name = ""
            if (len(api_name_label) > 0):
                api_name = api_name_label['data-text']
            api_name_dict = {"name" : api_name}
            api_item.update(api_name_dict)
            api_tables_labels = labels[y].find_all('table', attrs= {'class':"responsive"})
            p_desc_labels = labels[y].find_all('p')
            print('%%%%%%%%%%%%%%%')
            print(len(p_desc_labels))
            api_desc = ''
            for m in range(0, len(p_desc_labels)):
                desc = p_desc_labels[m].get_text().replace('\n', '')
                print(desc)
                print('##############')
                if desc not in api_desc:
                    api_desc +=  desc
            api_desc = api_desc.replace('\n', '')
            desc = {"desc" : api_desc}
            #print(desc)
            print('&&&&&&&&&&&&&&&&&&&&&&&')
            api_item.update(desc)

            see_also_labels = labels[y].find_all('ul')
            see_also_list = []
            api_item.update({"see_also": see_also_list})
            if(len(see_also_labels) > 0):
                #print(see_also_labels[0].find('a')['href'])
                for z in range(0, len(see_also_labels)):
                    if(see_also_labels[z]):
                        see_also_item_labels = see_also_labels[z].find_all('a')
                        if see_also_item_labels:
                            for r in range(0, len(see_also_item_labels)):
                                see_also_item_name = see_also_item_labels[r].get_text()
                                see_also_item_url = base_url + see_also_item_labels[r]['href']
                                item_info = {
                                    "info": see_also_item_name,
                                    "url": see_also_item_url
                                }
                                see_also_item = {"see_also": item_info}
                                see_also_list.append(see_also_item)
                        api_item.update({"see_also" :see_also_list})


            arg_list = []
            args_dict = {"args": arg_list}
            api_item.update(args_dict)

            return_dict = {}
            dict = {"return_value": return_dict}
            api_item.update(dict)

            throw_dict = {}
            dict = {"throw": throw_dict}
            api_item.update(dict)

            for i in range(0, len(api_tables_labels)):
                tr_labels = api_tables_labels[i].find_all('tr')
                print('******')
                print(len(tr_labels))
                if ('Parameters' == tr_labels[0].get_text()):
                    print('Parameters')
                    arg_list = []
                    for n in range(1, len(tr_labels)):
                        arg_item = {}
                        td_labels = tr_labels[n].find_all('td')
                        print('----')
                        arg_name = td_labels[0].get_text()
                        arg_type = td_labels[1].find('code').get_text()
                        arg_desc = td_labels[1].get_text()
                        print(arg_name)
                        print(arg_type)
                        arg_desc_withour_reline = arg_desc.replace('\n', '')
                        final_arg_desc = arg_desc_withour_reline.replace(arg_type + ':', "").strip()
                        print(final_arg_desc)
                        arg_item["name"] = arg_name
                        arg_item["type"] = arg_type
                        arg_item["desc"] = final_arg_desc
                        dict = {"arg" : arg_item}
                        arg_list.append(dict)
                    args_dict = {"args" : arg_list}
                    api_item.update(args_dict)
                elif ('Returns' == tr_labels[0].get_text()):
                    return_dict = {}
                    td_labels = tr_labels[1].find_all('td')
                    return_type = td_labels[0].find('code').get_text()
                    return_desc = td_labels[1].get_text().replace('\n', '')
                    print('Returns')
                    print(return_type)
                    print(return_desc)
                    return_dict["type"] = return_type
                    return_dict["desc"] = return_desc
                    dict = {"return_value" : return_dict}
                    api_item.update(dict)
                elif ('Throws' == tr_labels[0].get_text()):
                    throw_list = []
                    for u in range(1, len(tr_labels)):

                        print('Throws')
                        throw_dict = {}
                        td_labels = tr_labels[u].find_all('td')
                        throw_type = td_labels[0].find('code').get_text()
                        throw_desc = td_labels[1].get_text()
                        throw_dict["type"] = throw_type
                        throw_dict["desc"] = throw_desc
                        throw_list.append(throw_dict)
                        dict = {"throw": throw_list}
                    api_item.update(dict)
            item_dict = {"api_info" : api_item}
            api_list.append(item_dict)
    return api_list



def get_api_info_method(version, base_url, api_reference_url, evo_info, platform_info, origin_api_dict):
    print('begin get api info method')
    print(api_reference_url)
    api_list = []
    item_dict = {}
    html = get_url_result(api_reference_url)
    if html is None:
        return api_list
    soup = BeautifulSoup(html, 'html.parser')
    provider_info_labels = soup.find_all('table', attrs = {"class" : "jd-inheritance-table"})
    print(len(provider_info_labels))
    if len(provider_info_labels) == 0: # 部分网页不存在
        return api_list
    tr_provider_labels = provider_info_labels[0].find_all('tr')
    print(len(tr_provider_labels))
    provider_dict = {"provider" : ""}
    if (len(tr_provider_labels) > 1):
        td_provider_labels = tr_provider_labels[1].find('td', attrs = {"class" : "jd-inheritance-class-cell"})#[1].get_text()
        td_provider = ""
        if (len(td_provider_labels) == 1):
            td_provider = td_provider_labels.get_text().replace('\n', '').strip()
        provider_dict = {"provider" : td_provider}#package class
    else:
        td_provider_labels = tr_provider_labels[0].find('td',attrs={"class": "jd-inheritance-class-cell"})  # [1].get_text()
        td_provider = ""
        if (len(td_provider_labels) == 1):
            td_provider = td_provider_labels.get_text().replace('\n', '').strip()
        provider_dict = {"provider": td_provider}  # package class

    print(provider_dict)
    labels = soup.find_all('div', attrs = {"data-version-added" : version})
    for y in range(0, len(labels)):
        api_name_label = labels[y].find('h3', attrs = {"class" : "api-name"})
        api_name_label_id_text = ""
        if api_name_label and api_name_label['id']:
            api_name_label_id_text = api_name_label.get_text()
        if api_name_label_id_text in origin_api_dict.keys():

            api_item = {
                "api_version": platform_info["api_version"],
                "platform_version": platform_info["platform_version"],
                "url": api_reference_url,
                "api_evolution_info": evo_info
            }
            api_item.update(provider_dict)
            #api_item.update({"url" : api_reference_url})

            api_name = ""
            if (len(api_name_label) > 0):
                api_name = api_name_label['data-text']
            api_name_dict = {"name" : api_name}
            api_item.update(api_name_dict)
            api_tables_labels = labels[y].find_all('table', attrs= {'class':"responsive"})
            p_desc_labels = labels[y].find_all('p')
            print('%%%%%%%%%%%%%%%')
            print(len(p_desc_labels))
            api_desc = ''
            for m in range(0, len(p_desc_labels)):
                desc = p_desc_labels[m].get_text().replace('\n', '')
                print(desc)
                print('##############')
                if desc not in api_desc:
                    api_desc +=  desc
            api_desc = api_desc.replace('\n', '')
            desc = {"desc" : api_desc}
            #print(desc)
            print('&&&&&&&&&&&&&&&&&&&&&&&')
            api_item.update(desc)

            see_also_labels = labels[y].find_all('ul')
            see_also_list = []
            api_item.update({"see_also": see_also_list})
            if(len(see_also_labels) > 0):
                #print(see_also_labels[0].find('a')['href'])
                for z in range(0, len(see_also_labels)):
                    if(see_also_labels[z]):
                        see_also_item_labels = see_also_labels[z].find_all('a')
                        if see_also_item_labels:
                            for r in range(0, len(see_also_item_labels)):
                                see_also_item_name = see_also_item_labels[r].get_text()
                                see_also_item_url = base_url + see_also_item_labels[r]['href']
                                item_info = {
                                    "info": see_also_item_name,
                                    "url": see_also_item_url
                                }
                                see_also_item = {"see_also": item_info}
                                see_also_list.append(see_also_item)
                        api_item.update({"see_also" :see_also_list})


            arg_list = []
            args_dict = {"args": arg_list}
            api_item.update(args_dict)

            return_dict = {}
            dict = {"return_value": return_dict}
            api_item.update(dict)

            throw_dict = {}
            dict = {"throw": throw_dict}
            api_item.update(dict)

            for i in range(0, len(api_tables_labels)):
                tr_labels = api_tables_labels[i].find_all('tr')
                print('******')
                print(len(tr_labels))
                if ('Parameters' == tr_labels[0].get_text()):
                    print('Parameters')
                    arg_list = []
                    for n in range(1, len(tr_labels)):
                        arg_item = {}
                        td_labels = tr_labels[n].find_all('td')
                        print('----')
                        arg_name = td_labels[0].get_text()
                        arg_type = td_labels[1].find('code').get_text()
                        arg_desc = td_labels[1].get_text()
                        print(arg_name)
                        print(arg_type)
                        arg_desc_withour_reline = arg_desc.replace('\n', '')
                        final_arg_desc = arg_desc_withour_reline.replace(arg_type + ':', "").strip()
                        print(final_arg_desc)
                        arg_item["name"] = arg_name
                        arg_item["type"] = arg_type
                        arg_item["desc"] = final_arg_desc
                        dict = {"arg" : arg_item}
                        arg_list.append(dict)
                    args_dict = {"args" : arg_list}
                    api_item.update(args_dict)
                elif ('Returns' == tr_labels[0].get_text()):
                    return_dict = {}
                    td_labels = tr_labels[1].find_all('td')
                    return_type = td_labels[0].find('code').get_text()
                    return_desc = td_labels[1].get_text().replace('\n', '')
                    print('Returns')
                    print(return_type)
                    print(return_desc)
                    return_dict["type"] = return_type
                    return_dict["desc"] = return_desc
                    dict = {"return_value" : return_dict}
                    api_item.update(dict)
                elif ('Throws' == tr_labels[0].get_text()):
                    throw_list = []
                    for u in range(1, len(tr_labels)):

                        print('Throws')
                        throw_dict = {}
                        td_labels = tr_labels[u].find_all('td')
                        throw_type = td_labels[0].find('code').get_text()
                        throw_desc = td_labels[1].get_text()
                        throw_dict["type"] = throw_type
                        throw_dict["desc"] = throw_desc
                        throw_list.append(throw_dict)
                        dict = {"throw": throw_list}
                    api_item.update(dict)
            item_dict = {"api_info" : api_item}
            api_list.append(item_dict)
    return api_list



android_base_url = "https://developer.android.com"
api_url = "ttt"

def generate_evolution_info(target_version, evolution_time):
    for m in get_api_data_from_android.version_list:
        print(m)
    print(target_version - 1)
    from_version = str(target_version - 1)
    target_version = str(target_version)
    evolution_info = {
        "add_evolution_info" : {
                "from_version" : from_version,
                "to_version" : target_version,
                "direction": "added",
                "reason": "no",
                "time": evolution_time
        },
        "changed_evolution_info" : {
                 "from_version" : from_version,
                "to_version" : target_version,
                "direction": "change",
                "reason": "no",
                "time": evolution_time
        },
        "remove_evolution_info" : {
                "from_version" : from_version,
                "to_version" : target_version,
                "direction": "remove",
                "reason": "no",
                "time": evolution_time
        }
    }
    print(evolution_info)


def get_add_method_url_dict_data(origin_url):#first
    result = get_url_result(origin_url)
    soup = BeautifulSoup(result, 'html.parser')
    add_labels = soup.find_all('a', target="rightframe")
    target_add_urls_dict = {}
    for i in range(0, len(add_labels)):
        print('begin get url-----', i)
        url_href = add_labels[i]['href']
        api_target_url = android_base_url + url_href
        api_label = add_labels[i].find('b')
        api = api_label.get_text()
        api_target_url_prefix = api_target_url.split('#')[0]
        target_add_urls_dict.update({api_target_url_prefix : api_target_url})
    return target_add_urls_dict

def get_add_field_url_dict_data(origin_url):#first
    result = get_url_result(origin_url)
    soup = BeautifulSoup(result, 'html.parser')
    add_labels = soup.find_all('a', target="rightframe")
    target_add_urls_dict = {}
    for i in range(0, len(add_labels)):
        print('begin get url-----', i)
        url_href = add_labels[i]['href']
        api_target_url = android_base_url + url_href
        api_label = add_labels[i].get_text()
        print(api_label)
        #api = api_label.get_text()
        api_target_url_prefix = api_target_url.split('#')[0]
        target_add_urls_dict.update({api_target_url_prefix : api_target_url})
    return target_add_urls_dict

def get_add_constructor_url_dict_data(origin_url):#first
    result = get_url_result(origin_url)
    soup = BeautifulSoup(result, 'html.parser')
    add_labels = soup.find_all('a', target="rightframe")
    target_add_urls_dict = {}
    for i in range(0, len(add_labels)):
        print('begin get url-----', i)
        url_href = add_labels[i]['href']
        api_target_url = android_base_url + url_href
        api_label = add_labels[i].find('b')
        api = api_label.get_text()
        api_target_url_prefix = api_target_url.split('#')[0]
        target_add_urls_dict.update({api_target_url_prefix : api_target_url})
    return target_add_urls_dict

def write_version_add_method_url_file(version, data):
    file = './evolution/method_add_' + str(version) + '_version' + '.json'
    with open(file, "w" ) as f:
        json.dump(data, f)

def write_version_add_field_url_file(version, data):
    file = './evolution/field_add_' + str(version) + '_version' + '.json'
    with open(file, "w" ) as f:
        json.dump(data, f)

def write_version_add_constructor_url_file(version, data):
    file = './evolution/constructor_add_' + str(version) + '_version' + '.json'
    with open(file, "w" ) as f:
        json.dump(data, f)

def get_version_add_method_data(version):
    file =  './evolution/method_add_' + str(version) + '_version' + '.json'
    with open(file, 'r', encoding='utf-8') as f:
        data = json.load(f)
        #print(data)
        return data

def get_version_add_field_data(version):
    file =  './evolution/field_add_' + str(version) + '_version' + '.json'
    with open(file, 'r', encoding='utf-8') as f:
        data = json.load(f)
        #print(data)
        return data

def get_version_add_constructor_data(version):
    file =  './evolution/constructor_add_' + str(version) + '_version' + '.json'
    with open(file, 'r', encoding='utf-8') as f:
        data = json.load(f)
        #print(data)
        return data

detail_url_to_reference_list = {}
def get_add_method_detail_url_to_reference_data(origin_url):#second
    reference_base_url = "https://developer.android.com/"
    html = get_url_result(origin_url)
    soup = BeautifulSoup(html, 'html.parser')
    add_labels = soup.find_all('table', summary="Added Methods")
    for i in range(0, len(add_labels)):
        tr_labels = add_labels[i].find_all('tr')
        print(len(tr_labels))
        for j in range(1, len(tr_labels)):
            a_labels = tr_labels[j].find_all('a')
            if (len(a_labels) > 0):
                api_name_label = a_labels[0]['name']
                api_href = a_labels[1]['href'].replace('../', '')
                api_url = reference_base_url + api_href
                print(api_name_label)
                print(api_url)


def get_constructor_reference_add_data(version):
    file = './evolution/constructor_detail_to_reference_add_' + str(version) + '_version' + '.json'
    print(file)
    with open(file, 'r', encoding='utf-8') as f:
        data = json.load(f)
        #print(data)
        return data

def get_field_reference_add_data(version):
    file = './evolution/field_detail_to_reference_add_' + str(version) + '_version' + '.json'
    print(file)
    with open(file, 'r', encoding='utf-8') as f:
        data = json.load(f)
        #print(data)
        return data

def get_method_reference_add_data(version):
    file = './evolution/method_detail_to_reference_add_' + str(version) + '_version' + '.json'
    print(file)
    with open(file, 'r', encoding='utf-8') as f:
        data = json.load(f)
        #print(data)
        return data

#ToDo 将evolution文件中的数据，继续爬取url，获取具体的api数据存储起来

direction = "add" # "remove", "change"
target_version = 34  # to do
#method_change_url =get_api_data_from_android.base_diff_url % str(target_version) + get_api_data_from_android.api_evolution['method'][direction]
field_change_url =get_api_data_from_android.base_diff_url % str(target_version) + get_api_data_from_android.api_evolution['field'][direction]
#constructor_change_url =get_api_data_from_android.base_diff_url % str(target_version) + get_api_data_from_android.api_evolution['constructor'][direction]

evolution_time = get_api_data_from_android.evolution_time_dict[str(target_version)]
platform_version = get_api_data_from_android.api_platform_dict[str(target_version)]
print(field_change_url)
print(evolution_time)


'''
把如下界面html数据中对应的url写入词典，此为 method add 的url
view-source:https://developer.android.com/sdk/api_diff/34/changes/methods_index_additions
'''

#https://developer.android.com/reference/java/lang/Math#absExact(int)
'''
dict_data = get_version_add_method_data(target_version)
for key, value in dict_data.items():
    print(key)
    print(value)
print(len(dict_data))
print(type(dict_data))
'''
'''
已完成所有版本 add method url 数据
'''
#dict_data = get_add_method_url_dict_data(method_change_url)
#write_version_add_method_url_file(target_version, dict_data)

#dict_data = get_add_field_url_dict_data(field_change_url)
#write_version_add_field_url_file(target_version, dict_data)

#dict_data = get_add_constructor_url_dict_data(constructor_change_url)
#write_version_add_constructor_url_file(target_version, dict_data)



def write_constructor_add_evolution_data(target_version, data):
    file = './evolution/final_data/constructor_add_' + str(target_version)+ '_version' + '.json'
    with open(file, "w") as f:
        json.dump(data, f)

def write_method_add_evolution_data(target_version, data):
    file = './evolution/final_data/method_add_' + str(target_version)+ '_version' + '.json'
    with open(file, "w") as f:
        json.dump(data, f)

def write_field_add_evolution_data(target_version, data):
    file = './evolution/final_data/field_add_' + str(target_version)+ '_version' + '.json'
    with open(file, "w") as f:
        json.dump(data, f)


#evolution_info = generate_evolution_info(target_version, evolution_time)
#print(get_api_data_from_android.version_list)
#get_api_info("34", android_base_url, api_url, evolution_info, android_info)
#api_url = "https://developer.android.com/reference/android/media/tv/AdRequest.html#AdRequest(int,%20int,%20android.net.Uri,%20long,%20long,%20long,%20android.os.Bundle)"

evolution_info = {
    "direction": "add",
    "reason": "",
    "time": evolution_time
}

platform_info = {
    "api_version" : target_version,
    "platform_version" : platform_version
}

'''
add_type = "constructor" #, field, method
constructor_reference_dict_data = get_constructor_reference_add_data(target_version)
print(len(constructor_reference_dict_data))
final_api_evolution_list = []
for n in range(0, len(constructor_reference_dict_data)):

    api_name_dict = {}
    reference_url = constructor_reference_dict_data[n]['class_reference_url']
    api_name_list = constructor_reference_dict_data[n]['constructor_detail_to_reference']
    print(len(api_name_list))
    for m in range(0, len(api_name_list)):
        api_name = api_name_list[m]['api_item']['api_url'].split('#')[1].split('(')[0]
        if '.' in api_name:
            new_api_name_list = api_name.split('.')
            api_name = new_api_name_list[len(new_api_name_list) - 1]
        api_name_dict.update({api_name : api_name_list[m]['api_item']['api_name_label'].split('.ctor_added')[0] })
    print(api_name_dict.keys())
    print(api_name_dict.values())
    print(reference_url)
    result = get_api_info_constructor(str(target_version), android_base_url, reference_url, evolution_info, platform_info, api_name_dict)
    for x in range(0, len(result)):
        final_api_evolution_list.append(result[x])
write_constructor_add_evolution_data(target_version ,final_api_evolution_list)
'''

'''
xxx = get_url_result("https://developer.android.com/reference/android/service/voice/AlwaysOnHotwordDetector")
yyy = BeautifulSoup(xxx, 'html.parser')
print(yyy)
'''



add_type = "method" #, field, method
method_reference_dict_data = get_method_reference_add_data(target_version)
print(len(method_reference_dict_data))
final_api_evolution_list = []
for n in range(0, len(method_reference_dict_data)):
    api_name_dict = {}
    print(n)
    if (method_reference_dict_data[n]):
        reference_url = method_reference_dict_data[n]['class_reference_url']
        api_name_list = method_reference_dict_data[n]['method_detail_to_reference']
        print(len(api_name_list))
        for m in range(0, len(api_name_list)):
            api_name = api_name_list[m]['api_item']['api_url'].split('#')[1].split('(')[0]
            if '.' in api_name:
                new_api_name_list = api_name.split('.')
                api_name = new_api_name_list[len(new_api_name_list) - 1]
            api_name_dict.update({api_name : api_name_list[m]['api_item']['api_name_label'].split('_added')[0] })
        print(api_name_dict.keys())
        print(api_name_dict.values())
        print(reference_url)
        result = get_api_info_method(str(target_version), android_base_url, reference_url, evolution_info, platform_info, api_name_dict)
        for x in range(0, len(result)):
            final_api_evolution_list.append(result[x])

write_method_add_evolution_data(target_version ,final_api_evolution_list)



'''
add_type = "field" #, field, method
field_reference_dict_data = get_field_reference_add_data(target_version)
print(len(field_reference_dict_data))
final_api_evolution_list = []
for n in range(0, len(field_reference_dict_data)):
    api_name_dict = {}
    print(n)
    if (field_reference_dict_data[n]):
        reference_url = field_reference_dict_data[n]['class_reference_url']
        api_name_list = field_reference_dict_data[n]['field_detail_to_reference']
        print(len(api_name_list))
        for m in range(0, len(api_name_list)):
            api_name = api_name_list[m]['api_item']['api_url'].split('#')[1]
            api_name_url = api_name_list[m]['api_item']['api_url'].split('#')[0]
            api_name_dict.update({api_name: api_name_list[m]['api_item']['api_name_label']})
        print(api_name_dict.keys())
        print(api_name_dict.values())
        print(reference_url)

        result = get_api_info_field(str(target_version), android_base_url, reference_url, evolution_info, platform_info, api_name_dict)
        for x in range(0, len(result)):
            final_api_evolution_list.append(result[x])

write_field_add_evolution_data(target_version ,final_api_evolution_list)
'''


#print(api_list)
'''
reference_url = "https://developer.android.com/reference/java/util/DoubleSummaryStatistics.html"
result = get_api_info(str(target_version), android_base_url, reference_url, evolution_info, platform_info)
for x in range(0, len(result)):
    final_api_evolution_list.append(result[x])

write_constructor_add_evolution_data(target_version ,final_api_evolution_list)
'''
'''
    for value_item in api_name_dict.values():
        if 'YuvImag' in value_item:
            print('YuvImage in dict')
        else:
            print('no')'''