import os

from bs4 import BeautifulSoup
import json
import get_api_data_from_android
import requests
import time




html = """

"""

def get_url_result(url):
    session = requests.session()
    header = {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:95.0) Gecko/20100101 Firefox/95.0',
        'Connection': 'close'
    }
    try:
        res = session.get(url, headers=header, verify=False)
        return res.content
    except:
        print('get url happens wrong')
        return None

def get_package_summary_classes(package_summary_url, package):
    base_url = "https://developer.android.com"
    package_item_dict = {}
    class_list = []
    html = get_url_result(package_summary_url)
    if html is None:
        wrong_dict = {
            "wrong_url": "url happens wrong"
        }
        return class_list.append(wrong_dict)
    soup = BeautifulSoup(html, 'html.parser')

    h1_label = soup.find_all("h1", attrs={"id" : package})
    h2_labels = soup.find_all("h2")
    print(h2_labels)
    package_desc = ""
    if(h1_label):
        print('h1 label ', h1_label[0].get_text())
        #p_labels = h1_label[0].find_all_next('p')
        p_labels = h2_labels[0].find_all_previous("p")
        for n in range(len(p_labels)-1, -1, -1):
            #if p_labels[n]
            illegal_label_child = p_labels[n].find_all("td")
            if illegal_label_child:
                print("illegal")
            elif "Last updated" in p_labels[n].get_text():
                print("Last updated label")
            elif "Content and code samples" in p_labels[n].get_text():
                print("Content and code samples label")
            else:
                illegal_label_parent = p_labels[n].parent
                print(illegal_label_parent)
                package_desc += p_labels[n].get_text().replace('\n', '')

    print("package_desc  ", package_desc)
    #print("----------")
    package_item_dict.update({
        "package_name": package,
        "package_url" : package_summary_url,
        "package_desc" : package_desc

    })
    table_label = soup.find_all("table", attrs={"class" : "jd-sumtable-expando"})
    print('table label length:  ', len(table_label))

    evolution_version_info_label = soup.find_all("div", attrs={"class" : "api-level"})
    if evolution_version_info_label:
        print("evolution_version_info_label: ",len(evolution_version_info_label))
        package_evolution_info = evolution_version_info_label[0].get_text().replace('\n', '').strip()
        evolution_ref_url = base_url + evolution_version_info_label[0].find('a')['href']
        print(package_evolution_info)
        print(evolution_ref_url)
        package_item_dict.update({
            "evolution_desc_url" : evolution_ref_url,
            "evolution_basic_info" : package_evolution_info
        })

    for i in range(0, len(table_label)):
        h2_label = table_label[i].findPrevious()
        tr_label = table_label[i].find_all("tr")
        for j in range(0, len(tr_label)):
            class_item_dict = {}
            td_labels = tr_label[j].find_all("td")
            name_td_label = td_labels[0]
            desc_td_label = td_labels[1]
            class_name = name_td_label.get_text()
            class_url = base_url + name_td_label.find("a")["href"]
            class_desc = desc_td_label.get_text()#.replace('\n', '')#.replace('\xa0', '')
            class_desc_list = class_desc.split('\n')
            lines = [line.strip() for line in class_desc_list if len(line.strip()) > 0]
            class_desc_reformat = "".join(lines)
            class_item_dict.update({
                "class_name" : class_name,
                "class_url" : class_url,
                "class_desc" : class_desc_reformat
            })

            if h2_label and h2_label.get_text() == "Classes":
                #print("Classes")
                class_item_dict.update({
                    "class_type" : "Classes"
                })
            elif h2_label and h2_label.get_text() == "Interfaces":
                #print("Interfaces")
                class_item_dict.update({
                    "class_type": "Interfaces"
                })
            elif h2_label and h2_label.get_text() == "Exceptions":
                #print("Exceptions")
                class_item_dict.update({
                    "class_type": "Exceptions"
                })
            elif h2_label and h2_label.get_text() == "Enums":
                #print("Enums")
                class_item_dict.update({
                    "class_type": "Enums"
                })

            class_list.append(class_item_dict)
    package_item_dict.update({
        "class_list" : class_list
    })
    #print(package_item_dict)
    return package_item_dict

evolution_version = {1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21}

def get_class_detail_info_from_website(origin_url, class_basic_info):
    base_url = "https://developer.android.com"
    class_detail_dict = {
        "basic_info" : class_basic_info
    }
    html = get_url_result(origin_url)
    if html is None:
        return class_detail_dict
    soup = BeautifulSoup(html, 'html.parser')

    class_general_evolution_info_dict = {}
    class_info_block_label = soup.find_all("div", attrs = {"id" : "api-info-block"})
    if class_info_block_label:
        next_label = class_info_block_label[0].find_next("div", attrs={"class" : "api-level"})
        evolution_info = next_label.get_text().replace('\n', '').strip()
        evolution_version = ""#
        if(len(evolution_info.split("API level")) > 1):
            evolution_version = evolution_info.split("API level")[1].strip()
        class_general_evolution_info_dict.update({
            "evolution_info" : evolution_info,
            "evolution_version" : evolution_version
        })
    class_detail_dict.update({
        "class_general_evolution_info_dict" : class_general_evolution_info_dict
    })
    print("class_general_evolution_info    ", class_general_evolution_info_dict)
    extends_info_dict = {}
    api_signature_labels = soup.find_all("code", attrs = {"class" : "api-signature"})
    extends_general_desc = ""
    if api_signature_labels:
        for x in range(0, len(api_signature_labels)):
            general_desc = api_signature_labels[x].get_text().replace('\n', '')
            extends_general_desc += general_desc
        extends_general_desc.strip()
    if ("extends" not in extends_general_desc) and ("implements" not in extends_general_desc):
        extends_general_desc = ""
    print(extends_general_desc)
    extends_info_dict.update({
        "general_desc" : extends_general_desc
    })
    inheritance_table_labels = soup.find_all("table", attrs = {"class" : "jd-inheritance-table"})
    if inheritance_table_labels:
        td_labels = inheritance_table_labels[0].find_all("td", attrs={"class" : "jd-inheritance-class-cell"})
        parent_class_list = []
        print("inheritance_td_labels   " ,len(td_labels))
        for y in range(len(td_labels) - 2, -1, -1):
            parent_url_list = []
            a_labels = td_labels[y].find_all("a")
            if a_labels:
                for z in range(0, len(a_labels)):
                    parent_url_list.append(base_url + a_labels[z]['href'])
            parent_class_item = {
                "parent_class" : td_labels[y].get_text().replace('\n', ''),
                "parent_urls" : parent_url_list
            }
            parent_class_list.append(parent_class_item)
        extends_info_dict.update({
            "detail_info" : parent_class_list
        })
    class_detail_dict.update({
        "extends_info" : extends_info_dict
    })
    class_summary_dict = {}
    nested_class_list = []
    public_method_list = []
    public_constructor_list = []
    constant_list = []
    enum_value_list = []
    field_list = []
    inherit_method_list = []
    inherit_constant_list = []

    public_method_item = {}
    public_constructor_item = {}
    constant_item = {}
    enum_value_item = {}
    field_item = {}

    nested_class_tables = soup.find_all("table", attrs={"id" : "nestedclasses"})
    public_method_tables = soup.find_all("table", attrs={"id" : "pubmethods"})
    public_constructor_tables = soup.find_all("table", attrs={"id" : "pubctors"})
    constant_tables = soup.find_all("table", attrs={"id" : "constants"})
    enum_value_tables = soup.find_all("table", attrs={"id" : "enumconstants"})
    field_tables = soup.find_all("table", attrs={"id" : "lfields"})
    inherit_method_tables = soup.find_all("table", attrs={"id" : "inhmethods"})
    inherit_constant_tables = soup.find_all("table", attrs={"id" : "inhconstants"})

    if inherit_constant_tables:
        print("inherit class tables length,  ", len(inherit_constant_tables))
        inherit_parent_label = inherit_constant_tables[0].find_all("div", attrs={"class": "expandable jd-inherited-apis"})
        if inherit_parent_label:
            print("inherit parent tables length,  ", len(inherit_parent_label))
            all_inherit_list = []
            for q in range(0, len(inherit_parent_label)):
                inherit_item = {}
                inherit_parent_class_name = ""
                inherit_parent_url = ""
                inherit_parent_class_name_label = inherit_parent_label[q].find_all("span",
                                                                                   attrs={"class": "expand-control"})
                if inherit_parent_class_name_label:
                    inherit_parent_class_name = inherit_parent_class_name_label[0].get_text().replace('\n', '')
                    if inherit_parent_class_name_label[0].find_all('a'):
                        inherit_parent_url = base_url + inherit_parent_class_name_label[0].find_all('a')[0]["href"]
                inherit_item.update({
                    "inherit_parent_class_name": inherit_parent_class_name,
                    "inherit_parent_url": inherit_parent_url
                })
                inserted_table_labels = inherit_parent_label[q].find_all("table", attrs={"class": "responsive"})
                tr_inherit_labels = inserted_table_labels[0].find_all("tr", recursive=False)
                if tr_inherit_labels and len(tr_inherit_labels) > 0:
                    item_method_list = []
                    for p in range(0, len(tr_inherit_labels)):
                        td_inherit_labels_in_tr_labels = tr_inherit_labels[p].find_all("td")
                        origin_type = td_inherit_labels_in_tr_labels[0].get_text()
                        origin_type_a_label = td_inherit_labels_in_tr_labels[0].find_all("a")
                        type_url_list = []
                        if origin_type_a_label:
                            for w in range(0, len(origin_type_a_label)):
                                type_url_list.append(base_url + origin_type_a_label[w]["href"])
                        inherit_return_type = origin_type.replace('\xa0', ' ').replace('\n', '').strip()
                        origin_desc_label = td_inherit_labels_in_tr_labels[1].find_all("p")
                        inherit_method_desc = ""
                        if origin_desc_label:
                            inherit_method_desc = origin_desc_label[0].get_text().replace('\xa0', ' ').replace('\n',
                                                                                                               '').strip()
                        inherit_method_desc_a_label = td_inherit_labels_in_tr_labels[1].find_all("a")
                        desc_url = ""
                        method_name = ""
                        method_name_label = td_inherit_labels_in_tr_labels[1].find_all("code")
                        if inherit_method_desc_a_label:
                            desc_url = base_url + inherit_method_desc_a_label[0]["href"]
                        if method_name_label:
                            method_name = method_name_label[0].get_text().replace('\n', '')
                        inherit_method_item = {
                            "constant_name": method_name,
                            "constant_type": inherit_return_type,
                            "constant_type_url": type_url_list,
                            "desc": inherit_method_desc,
                            "desc_url": desc_url
                        }
                        item_method_list.append(inherit_method_item)
                    inherit_item.update({
                        "inherit_method_list": item_method_list
                    })
                # all_inherit_list.append(inherit_item)
                inherit_constant_list.append(inherit_item)
    class_summary_dict.update({
        "inherit_constant_info" : inherit_constant_list
    })

    if public_constructor_tables:
        print("public constructor table length,  ", len(public_constructor_tables))
        tr_public_constructors_labels = public_constructor_tables[0].find_all("tr", recursive=False)
        if tr_public_constructors_labels and len(tr_public_constructors_labels) > 1:
            for v in range(1, len(tr_public_constructors_labels)):
                constructor_name_label = tr_public_constructors_labels[v].find_all("code")
                constructor_desc_label = tr_public_constructors_labels[v].find_all("p")
                constructor_name = ""
                constructor_desc = ""
                constructor_desc_url = ""
                if constructor_name_label:
                    constructor_name = constructor_name_label[0].get_text().replace('\n', '').strip()
                if constructor_desc_label:
                    constructor_desc = constructor_desc_label[0].get_text().replace('\n', '').strip()
                    constructor_desc_url_label = constructor_desc_label[0].find_all("a")
                    if constructor_desc_url_label:
                        constructor_desc_url = base_url + constructor_desc_url_label[0]["href"]
                public_constructor_item = {
                    "constructor_name" : constructor_name,
                    "constructor_desc" : constructor_desc,
                    "constructor_desc_url" : constructor_desc_url
                }
                public_constructor_list.append(public_constructor_item)
    class_summary_dict.update({
        "constructor_info" : public_constructor_list
    })

    if field_tables:
        print("field tables length,  ", len(field_tables))
        tr_field_labels = field_tables[0].find_all("tr", recursive=False)
        if tr_field_labels and len(tr_field_labels):
            for b in range(1, len(tr_field_labels)):
                td_field_labels_in_tr_labels = tr_field_labels[b].find_all("td")
                origin_field_type = ""
                origin_field_type_url = ""
                field_name = ""
                field_desc = ""
                field_desc_url = ""
                origin_field_type_label = td_field_labels_in_tr_labels[0].find_all("code")
                if origin_field_type_label:
                    origin_field_type = origin_field_type_label[0].get_text().replace('\n', '')
                    origin_field_type_url_label = origin_field_type_label[0].find_all("a")
                    if origin_field_type_url_label:
                        origin_field_type_url = base_url + origin_field_type_url_label[0]["href"]
                field_name_label = td_field_labels_in_tr_labels[1].find_all("code")
                if field_name_label:
                    field_name = field_name_label[0].get_text().replace('\n', '').strip()
                field_desc_label = td_field_labels_in_tr_labels[1].find_all("p")
                if field_desc_label:
                    field_desc = field_desc_label[0].get_text().replace('\n', '').strip()
                    field_desc_url_label = field_desc_label[0].find_all("a")
                    if field_desc_url_label:
                        field_desc_url = base_url + field_desc_url_label[0]["href"]
                field_item = {
                    "field_name" : field_name,
                    "field_desc" : field_desc,
                    "field_type" : origin_field_type,
                    "field_type_url" : origin_field_type_url,
                    "field_desc_url" : field_desc_url
                }
                field_list.append(field_item)
    class_summary_dict.update({
        "field_info" : field_list
    })


    if constant_tables:
        print("tr_constants_labels,  ", len(constant_tables))
        tr_constants_labels = constant_tables[0].find_all("tr", recursive=False)
        if tr_constants_labels and len(tr_constants_labels) > 1:
            for v in range(1, len(tr_constants_labels)):
                td_constans_labels_in_tr_labels = tr_constants_labels[v].find_all("td")
                origin_constant_type_code_label = td_constans_labels_in_tr_labels[0].find_all("code")
                origin_constant_type_url_a_label = td_constans_labels_in_tr_labels[0].find_all("a")
                constant_name_label = td_constans_labels_in_tr_labels[1].find_all("code")
                constant_desc_label = td_constans_labels_in_tr_labels[1].find_all("p")
                origin_constant_type = ""
                origin_constant_type_url = ""
                constant_name = ""
                constant_desc = ""
                constant_desc_url = ""
                if origin_constant_type_code_label:
                    origin_constant_type = origin_constant_type_code_label[0].get_text().replace('\n', '')
                if origin_constant_type_url_a_label:
                    origin_constant_type_url = base_url + origin_constant_type_url_a_label[0]["href"]
                if constant_name_label:
                    constant_name = constant_name_label[0].get_text().replace('\n', '')
                if constant_desc_label:
                    constant_desc = constant_desc_label[0].get_text().replace('\n', '')
                    constant_desc_url_label = constant_desc_label[0].find_all("a")
                    if constant_desc_url_label:
                        constant_desc_url = base_url +  constant_desc_url_label[0]["href"]
                constant_item = {
                    "constant_name" : constant_name,
                    "constant_desc" : constant_desc,
                    "constant_type" : origin_constant_type,
                    "constant_type_url" : origin_constant_type_url,
                    "constant_desc_url" : constant_desc_url
                }
                constant_list.append(constant_item)
    class_summary_dict.update({
        "constant_info" : constant_list
    })


    if enum_value_tables:
        print("enum value tables,  ", len(enum_value_tables))
        tr_enum_labels = enum_value_tables[0].find_all("tr", recursive=False)
        if tr_enum_labels and len(tr_enum_labels) > 1 :
            for u in range(1, len(tr_enum_labels)):
                td_enum_labels_in_tr_labels = tr_enum_labels[u].find_all("td")
                origin_enum_type_code_label = td_enum_labels_in_tr_labels[0].find_all("code")
                origin_enum_type = ""
                if origin_enum_type_code_label:
                    origin_enum_type = origin_enum_type_code_label[0].get_text().replace('\n', '')

                origin_enum_type_a_label = td_enum_labels_in_tr_labels[0].find_all("a")
                origin_enum_type_url = ""
                if origin_enum_type_a_label:
                    origin_enum_type_url = base_url + origin_enum_type_a_label[0]["href"]
                enum_value_name_label = td_enum_labels_in_tr_labels[1].find_all("code")
                enum_value_desc_label = td_enum_labels_in_tr_labels[1].find_all("p")
                enum_value_desc_url_label = td_enum_labels_in_tr_labels[1].find_all("a")
                enum_value_name = ""
                enum_value_desc = ""
                enum_value_desc_url = ""
                if enum_value_name_label:
                    enum_value_name = enum_value_name_label[0].get_text()
                if enum_value_desc_label:
                    enum_value_desc = enum_value_desc_label[0].get_text().replace("\n", '').replace('\u00a0', '').strip()
                if enum_value_desc_url_label:
                    enum_value_desc_url = base_url + enum_value_desc_url_label[0]["href"]
                enum_item = {
                    "enum_name": enum_value_name,
                    "enum_type" : origin_enum_type,
                    "enum_type_url" : origin_enum_type_url,
                    "enum_desc" : enum_value_desc,
                    "enum_desc_url" : enum_value_desc_url
                }
                enum_value_list.append(enum_item)

    class_summary_dict.update({
        "enum_value_info" : enum_value_list
    })

    if nested_class_tables:
        print("nested class tables length,  ", len(nested_class_tables))
        tr_nested_labels = nested_class_tables[0].find_all("tr", recursive=False)
        if tr_nested_labels and len(tr_nested_labels) > 1:
            for p in range(1, len(tr_nested_labels)):
                td_nested_labels_in_tr_labels = tr_nested_labels[p].find_all("td")
                #nested_class_name \
                origin_type = td_nested_labels_in_tr_labels[0].get_text()
                origin_desc = td_nested_labels_in_tr_labels[1].get_text()
                nested_class_name_label = td_nested_labels_in_tr_labels[1].find_all("code")
                nested_class_name = ""
                if nested_class_name_label:
                    nested_class_name = nested_class_name_label[0].get_text().replace('\xa0', ' ').replace('\n', '').strip()
                nested_class_desc_label = td_nested_labels_in_tr_labels[1].find_all("p")
                nested_class_desc = ""
                if nested_class_desc_label:
                    nested_class_desc = nested_class_desc_label[0].get_text().replace('\xa0', ' ').replace('\n', '').strip()
                nested_class_type = origin_type.replace('\xa0', ' ').replace('\n', '').strip()
                nested_class_desc_a_label = td_nested_labels_in_tr_labels[1].find_all("a")
                nested_class_desc_url = ""
                if nested_class_desc_a_label:
                    nested_class_desc_url = base_url + nested_class_desc_a_label[0]["href"]
                nested_class_item = {
                    "name" :nested_class_name,
                    "type": nested_class_type,
                    "desc": nested_class_desc,
                    "desc_url" : nested_class_desc_url
                }
                nested_class_list.append(nested_class_item)
    class_summary_dict.update({
        "nested_class_info" : nested_class_list
    })

    if public_method_tables:
        print("public_method_tables  length,  ", len(public_method_tables))
        tr_public_method_labels = public_method_tables[0].find_all("tr", recursive=False)
        if tr_public_method_labels and len(tr_public_method_labels) > 1:
            for o in range(1, len(tr_public_method_labels)):
                td_public_method_labels_in_tr_labels = tr_public_method_labels[o].find_all("td")
                return_type_url = ""
                origin_return_type = td_public_method_labels_in_tr_labels[0].get_text()
                origin_return_type_a_label = td_public_method_labels_in_tr_labels[0].find_all("a")
                if origin_return_type_a_label:
                    return_type_url = base_url + origin_return_type_a_label[0]["href"]

                origin_desc_label = td_public_method_labels_in_tr_labels[1].find_all("p")
                public_method_desc = ""
                if origin_desc_label:
                    public_method_desc = origin_desc_label[0].get_text().replace('\xa0', ' ').replace('\n', '').strip()
                return_type = origin_return_type.replace('\xa0', ' ').replace('\n', '').strip()
                public_method_desc_a_label = td_public_method_labels_in_tr_labels[1].find_all("a")
                public_method_desc_url = ""
                method_name = ""
                if public_method_desc_a_label:
                    public_method_desc_url = base_url + public_method_desc_a_label[0]["href"]
                public_method_name_label = td_public_method_labels_in_tr_labels[1].find_all("code")
                if public_method_name_label:
                    method_name = public_method_name_label[0].get_text().replace('\n', '')
                public_method_item = {
                    "method_name": method_name,
                    "return_type": return_type,
                    "return_type_url": return_type_url,
                    "desc": public_method_desc,
                    "desc_url": public_method_desc_url
                }
                public_method_list.append(public_method_item)
    class_summary_dict.update({
        "public_method_info": public_method_list
    })

    if inherit_method_tables:
        print("inherit class tables length,  ", len(inherit_method_tables))
        inherit_parent_label = inherit_method_tables[0].find_all("div", attrs={"class": "expandable jd-inherited-apis"})
        if inherit_parent_label:
            print("inherit parent tables length,  ", len(inherit_parent_label))
            all_inherit_list = []
            for q in range(0, len(inherit_parent_label)):
                inherit_item = {}
                inherit_parent_class_name = ""
                inherit_parent_url = ""
                inherit_parent_class_name_label = inherit_parent_label[q].find_all("span", attrs={"class":"expand-control"})
                if inherit_parent_class_name_label:
                    inherit_parent_class_name = inherit_parent_class_name_label[0].get_text().replace('\n', '')
                    if inherit_parent_class_name_label[0].find_all('a'):
                        inherit_parent_url = base_url + inherit_parent_class_name_label[0].find_all('a')[0]["href"]
                inherit_item.update({
                    "inherit_parent_class_name": inherit_parent_class_name,
                    "inherit_parent_url" : inherit_parent_url
                })
                inserted_table_labels = inherit_parent_label[q].find_all("table", attrs = {"class" : "responsive"})
                tr_inherit_labels = inserted_table_labels[0].find_all("tr", recursive=False)
                if tr_inherit_labels and len(tr_inherit_labels) > 0:
                    item_method_list = []
                    for p in range(0, len(tr_inherit_labels)):
                        td_inherit_labels_in_tr_labels = tr_inherit_labels[p].find_all("td")
                        origin_type = td_inherit_labels_in_tr_labels[0].get_text()
                        origin_type_a_label = td_inherit_labels_in_tr_labels[0].find_all("a")
                        type_url_list = []
                        if origin_type_a_label:
                            for w in range(0, len(origin_type_a_label)):
                                type_url_list.append(base_url + origin_type_a_label[w]["href"])
                        inherit_return_type = origin_type.replace('\xa0', ' ').replace('\n', '').strip()
                        origin_desc_label = td_inherit_labels_in_tr_labels[1].find_all("p")
                        inherit_method_desc = ""
                        if origin_desc_label:
                            inherit_method_desc = origin_desc_label[0].get_text().replace('\xa0', ' ').replace('\n', '').strip()
                        inherit_method_desc_a_label = td_inherit_labels_in_tr_labels[1].find_all("a")
                        desc_url = ""
                        method_name = ""
                        method_name_label = td_inherit_labels_in_tr_labels[1].find_all("code")
                        if inherit_method_desc_a_label:
                            desc_url = base_url + inherit_method_desc_a_label[0]["href"]
                        if method_name_label:
                            method_name = method_name_label[0].get_text().replace('\n', '')
                        inherit_method_item = {
                            "method_name": method_name,
                            "return_type": inherit_return_type,
                            "return_type_url":type_url_list,
                            "desc": inherit_method_desc,
                            "desc_url": desc_url
                        }
                        item_method_list.append(inherit_method_item)
                    inherit_item.update({
                        "inherit_method_list" : item_method_list
                    })
                #all_inherit_list.append(inherit_item)
                inherit_method_list.append(inherit_item)

        class_summary_dict.update({
            "inherit_method_info": inherit_method_list
        })
        print(class_summary_dict)

    class_detail_dict.update({
        "summary_dict" : class_summary_dict
    })

    class_detail_desc = ""
    h2_summary_labels = soup.find_all("h2", attrs = {"id" : "summary"})
    if h2_summary_labels:
        print("h2 summary label  ", h2_summary_labels[0].get_text())
        p_labels = h2_summary_labels[0].find_all_previous("p")
        print("p_labels   length   ", len(p_labels))
        for n in range(len(p_labels) - 1, -1, -1):
            if "Last updated" in p_labels[n].get_text():
                print("Last updated label")
            elif "Content and code samples" in p_labels[n].get_text():
                print("Content and code samples label")
            else:
                print("----else")
                #illegal_label_parent = p_labels[n].parent
                #print(illegal_label_parent)
                class_detail_desc += p_labels[n].get_text().replace('\n', '').strip()+"##########"
        class_detail_desc = class_detail_desc.split("Summary")[0]
        if(len(class_detail_desc.split("##########")) > 1):
            class_detail_desc = class_detail_desc.split("##########")[1]

    class_detail_dict.update({
        "class_detail_desc": class_detail_desc
    })


    version_all_api_list = []
    for version_id in range(1, 35): # to do
        #print(version_id)
        div_version_labels = soup.find_all("div", attrs={"data-version-added" : str(version_id)})
        if div_version_labels:
            print("version id, ", version_id)
            version_api_list = []
            version_item_dict = {}
            for z in range(0, len(div_version_labels)):
                illegal_label = div_version_labels[z].find_all("code", attrs={"class" : "api-signature"})
                if not illegal_label:
                    version_api_item = {}
                    api_name_h3_label = div_version_labels[z].find_all("h3", attrs = {"class" : "api-name"})
                    api_name = ""#
                    api_level_label = div_version_labels[z].find_all("div", attrs = {"class" : "api-level"})
                    if api_name_h3_label:
                        api_name = api_name_h3_label[0]["data-text"]
                    api_level_desc = ""
                    if api_level_label:
                        api_level_desc = api_level_label[0].get_text().replace('\n', '')
                    deprecated_desc = ""
                    if (len(api_level_desc.split("Deprecated")) > 1):
                        deprecated_desc = "Deprecated " + api_level_desc.split("Deprecated")[1]

                    basic_evolution_info_dict = {
                        "added_desc" : "Added in API level " + str(version_id),
                        "evolution_version" : str(version_id),
                        "deprecated_desc" : deprecated_desc
                    }
                    version_api_item.update({
                        "basic_evolution_info" : basic_evolution_info_dict
                    })
                    api_desc = ""
                    api_desc_labels = div_version_labels[z].find_all("p", recursive=False)
                    exclude_text = ""

                    for r in range(0, len(api_desc_labels)):
                        #whether_hr_br_label = api_desc_labels[r].find_previous()
                        #if('<hr' not in str(whether_hr_br_label)):
                            #print("exclude a page's title p content")
                        api_desc += api_desc_labels[r].get_text().replace('\n', "")
                    version_api_item.update({
                        "api_name" : api_name,
                        "api_desc" : api_desc
                    })

                    see_also_labels = div_version_labels[z].find_all('ul')
                    see_also_list = []
                    version_api_item.update({"see_also": see_also_list})
                    if (len(see_also_labels) > 0):
                        # print(see_also_labels[0].find('a')['href'])

                        for s in range(0, len(see_also_labels)):
                            ul_previous_label = see_also_labels[s].find_previous()
                            if ("See also:" in str(ul_previous_label)):
                                see_also_item_labels = see_also_labels[s].find_all('a')
                                if see_also_item_labels:
                                    for r in range(0, len(see_also_item_labels)):
                                        see_also_item_name = see_also_item_labels[r].get_text()
                                        see_also_item_url = base_url + see_also_item_labels[r]['href']
                                        item_info = {
                                            "info": see_also_item_name,
                                            "url": see_also_item_url
                                        }
                                        see_also_item = {"see_also": item_info}
                                        see_also_list.append(see_also_item)
                                version_api_item.update({"see_also": see_also_list})

                    arg_list = []
                    args_dict = {"args": arg_list}
                    version_api_item.update(args_dict)

                    return_dict = {}
                    dict = {"return_value": return_dict}
                    version_api_item.update(dict)

                    throw_dict = {}
                    dict = {"throw": throw_dict}
                    version_api_item.update(dict)

                    api_arg_return_table_labels = div_version_labels[z].find_all('table', attrs= {'class':"responsive"})

                    for i in range(0, len(api_arg_return_table_labels)):
                        tr_labels = api_arg_return_table_labels[i].find_all('tr')
                        print('******')
                        print(len(tr_labels))
                        if ('Parameters' == tr_labels[0].get_text()):
                            print('Parameters')
                            arg_list = []
                            for n in range(1, len(tr_labels)):
                                arg_item = {}
                                td_labels = tr_labels[n].find_all('td')
                                print('----')
                                arg_name = td_labels[0].get_text()
                                arg_type = td_labels[1].find('code').get_text()
                                arg_desc = td_labels[1].get_text()
                                print(arg_name)
                                print(arg_type)
                                arg_desc_withour_reline = arg_desc.replace('\n', '')
                                final_arg_desc = arg_desc_withour_reline.replace(arg_type + ':', "").strip()
                                print(final_arg_desc)
                                arg_item["name"] = arg_name
                                arg_item["type"] = arg_type
                                arg_item["desc"] = final_arg_desc
                                dict = {"arg": arg_item}
                                arg_list.append(dict)
                            args_dict = {"args": arg_list}
                            version_api_item.update(args_dict)
                        elif ('Returns' == tr_labels[0].get_text()):
                            return_dict = {}
                            td_labels = tr_labels[1].find_all('td')
                            return_type = td_labels[0].find('code').get_text()
                            return_desc = td_labels[1].get_text().replace('\n', '')
                            return_type_a_label = td_labels[0].find('code').find_all("a")
                            return_type_url = ""
                            if return_type_a_label:
                                return_type_url = base_url + return_type_a_label[0]["href"]
                            print('Returns')
                            print(return_type)
                            print(return_desc)
                            return_dict["type"] = return_type
                            return_dict["desc"] = return_desc
                            return_dict["type_url"] = return_type_url
                            dict = {"return_value": return_dict}
                            version_api_item.update(dict)
                        elif ('Throws' == tr_labels[0].get_text()):
                            throw_list = []
                            for u in range(1, len(tr_labels)):
                                print('Throws')
                                throw_dict = {}
                                td_labels = tr_labels[u].find_all('td')
                                throw_type = td_labels[0].find('code').get_text()
                                throw_desc = td_labels[1].get_text()
                                throw_dict["type"] = throw_type
                                throw_dict["desc"] = throw_desc
                                throw_list.append(throw_dict)
                                dict = {"throw": throw_list}
                            version_api_item.update(dict)
                    #item_dict = {"api_info": api_item}
                    #api_list.append(item_dict)
                    if(version_api_item["api_name"] != ""):
                        version_api_list.append(version_api_item)

                    version_item_dict = {
                        "evolution_version" : str(version_id),
                        "concrete_version_api_info" : version_api_list
                    }
            version_all_api_list.append(version_item_dict)
    #print(class_detail_dict)
    class_detail_dict.update({
        "concrete_version_api_info" : version_all_api_list
    })
    return class_detail_dict
        #print(class_detail_desc)
    #print("class_detail_desc    ",  class_detail_desc)

def get_platform_base_package_from_website(website_url):
    base_url = "https://developer.android.com"
    package_list = []
    html = get_url_result(website_url)
    if html is None:
        return package_list
    soup = BeautifulSoup(html, 'html.parser')
    table_label = soup.find_all("table")
    print('table label length:  ', len(table_label))

    for i in range(0, len(table_label)):
        tr_labels = table_label[i].find_all('tr')
        for j in range(0, len(tr_labels)):

            package_item_info = {
                "package_name" : "",
                "package_desc" : "",
                "package_url"  : ""
            }
            a_label = tr_labels[j].find('a')
            package_name = a_label.get_text()
            package_url = a_label['href']
            p_label = a_label.find('p')
            package_desc = ""
            if p_label:
                package_desc = p_label.get_text()
                #print(package_desc)
            package_item_info.update({
                "package_name": package_name,
                "package_desc": package_desc,
                "package_url": base_url + package_url
            })
            package_list.append(package_item_info)

    return package_list




#from 1 to 21 version
def write_android_platform_base_package(data):
    file_prefix = './evolution/android_platform_base_package/platform_base_package_info_' #+ '.json'
    for i in range(0, len(data)):
        package_file = file_prefix + str(i) + '_' + '.json'
        with open(package_file, "w") as f:
            json.dump(data[i], f)

def write_android_platform_base_classes(data, id):
    file_prefix = './evolution/android_platform_base_class/platform_package_with_class_info_'  # + '.json'
    package_file = file_prefix + str(id) + '_' + '.json'
    with open(package_file, "w") as f:
        json.dump(data, f)

def write_android_platform_class_detail(data, id):
    file_prefix = './evolution/android_platform_class_detail/platform_package_with_class_detail_info_'  # + '.json'
    package_file = file_prefix + str(id) + '_' + '.json'
    with open(package_file, "w") as f:
        json.dump(data, f)

def get_android_platform_base_package_data(id):
    file_prefix = "./evolution/android_platform_base_package/platform_base_package_info_"
    file = file_prefix + str(id) + '_' + '.json'
    with open(file, 'r', encoding='utf-8') as f:
        data = json.load(f)
        return data

def get_android_platform_base_class_data(id):
    file_prefix = "./evolution/android_platform_base_class/platform_package_with_class_info_"
    file = file_prefix + str(id) + '_' + '.json'
    with open(file, 'r', encoding='utf-8') as f:
        data = json.load(f)
        return data

def get_android_platform_class_detail_data(id):
    file_prefix = './evolution/android_platform_class_detail/platform_package_with_class_detail_info_'  # + '.json'
    file = file_prefix + str(id) + '_' + '.json'
    with open(file, 'r', encoding='utf-8') as f:
        data = json.load(f)
        return data



platform_package_url = "https://developer.android.com/reference/packages"
androidx_package_url = ""

#package_id = 4
'''
for package_id in range(260, 267):
    class_detail_data_list = []
    one_package_with_class_data = get_android_platform_base_class_data(package_id)
    for class_id in range(0, len(one_package_with_class_data["class_list"])):
        class_basic_info = {
            "abbreviation_name": one_package_with_class_data["class_list"][class_id]["class_name"],
            "full_name": one_package_with_class_data["package_name"] + '.' + one_package_with_class_data["class_list"][class_id]["class_name"],
            "class_type": one_package_with_class_data["class_list"][class_id]["class_type"],
            "class_url" :one_package_with_class_data["class_list"][class_id]["class_url"]
        }
        print("package id, ", package_id)
        print("class name,  ", class_basic_info["full_name"])
        class_detail_data = get_class_detail_info_from_website(class_basic_info["class_url"], class_basic_info)
        class_detail_data_list.append(class_detail_data)
    write_android_platform_class_detail(class_detail_data_list, package_id)
'''
#print(one_package_with_class_data["package_name"])
#url_test = "https://developer.android.com/reference/android/app/appsearch/AppSearchBatchResult"
#url_test = "https://developer.android.com/reference/android/util/JsonToken"
#url_test = "https://developer.android.com/reference/android/provider/Settings.Secure.html#ALLOW_MOCK_LOCATION"
#url_test = "https://developer.android.com/reference/android/app/appsearch/BatchResultCallback"
#url_test = "https://developer.android.com/reference/android/app/appsearch/observer/DocumentChangeInfo"
#url_test = "https://developer.android.com/reference/android/nfc/cardemulation/HostApduService"
#url_test = "https://developer.android.com/reference/android/accounts/AbstractAccountAuthenticator"
#url_test = "https://developer.android.com/reference/android/view/accessibility/AccessibilityEvent#isAccessibilityDataSensitive()"
#url_test = "https://developer.android.com/reference/android/Manifest"
#url_test = "https://developer.android.com/reference/android/R.styleable"
#class_detail_data = get_class_detail_info_from_website(url_test, {})
#write_android_platform_class_detail(class_detail_data, 8)



#package_data = get_platform_base_package_from_website(platform_package_url)
#print(package_data)
#print(len(package_data))
#write_android_platform_base_package(package_data)

'''
for id in range(0, 267):
    data = get_android_platform_base_package_data(id)
    package_summary_url = data['package_url']
    package_name = data["package_name"]
    print(id, "   ", package_summary_url)
    package_with_class_data = get_package_summary_classes(package_summary_url, package_name)
    write_android_platform_base_classes(package_with_class_data, id)
'''


'''
data = get_android_platform_base_package_data(0)
print(data)
package_summary_url = data['package_url']
#print(package_summary_url)
#package_with_class_data = get_package_summary_classes("https://developer.android.com/reference/android/app/backup/package-summary", "android.app.backup")
package_with_class_data = get_package_summary_classes("https://developer.android.com/reference/android/adservices/adselection/package-summary", "android.adservices.adselection")

#write_android_platform_base_classes(package_with_class_data, 0)
'''


#有的文件字典里面没有"summary_dict"字段，需要排查，文件id有16,57, 65, 75, 76, 86, 112, 118, 120, 123
count = 0
class_count = 0
for j in range(0, 267):
    #print("file number:  ", j)
    detail_data = get_android_platform_class_detail_data(j)
    full_name = detail_data[0]["basic_info"]["full_name"]
    abbr_name = detail_data[0]["basic_info"]["abbreviation_name"]
    package_name = full_name.replace("." + abbr_name, "")
    #print("package name: ", package_name)
    #if package_name == "android.content.pm":
    for i in range(0, len(detail_data)):
        class_count += 1
        #print("file number: ", j, "detail data number:   ", i, detail_data[i]["basic_info"]["full_name"], "  ", detail_data[i]["basic_info"]["class_url"])
        if "summary_dict" in detail_data[i].keys():
            summary_dict = detail_data[i]["summary_dict"]
            constructor_info = summary_dict["constructor_info"]
            field_info = summary_dict["field_info"]
            constant_info = summary_dict["constant_info"]
            enum_value_info = summary_dict["enum_value_info"]
            nested_class_info = summary_dict["nested_class_info"]
            public_method_info = summary_dict["public_method_info"]
            class_item_count= len(constructor_info) + len(field_info) + \
                              len(constant_info) + len(enum_value_info) + \
                              len(nested_class_info) + len(public_method_info)
            #print("file number: ", j ,"class item count:   ", class_item_count)
            count += class_item_count
print("basic API count:  ", count)
print("basic class count: ", class_count)


'''class_count = 0
for m in range(0, 267):
    base_class_data = get_android_platform_base_class_data(m)
    class_list = base_class_data["class_list"]
    class_count += len(class_list)
print(class_count)
'''


def calculate_evolution_data_count(): # add change
    evolution_count = 0
    file_list = os.listdir("./evolution/final_data")
    print("file_list len: ", len(file_list))
    file_path = "./evolution/final_data/"
    for m in range(0, len(file_list)):
        file =  file_path + file_list[m]
        with open(file, 'r', encoding='utf-8') as f:
            data = json.load(f)
            # print(data)
            #print("file: ", file, "### data len: ", len(data))
            evolution_count += len(data)
    return evolution_count

evolution_count = calculate_evolution_data_count()
print("evolution data count: ", evolution_count)


'''
method_detail_to_reference_remove_33_version.json
field_detail_to_reference_remove_33_version.json
constructor_detail_to_reference_remove_33_version.json
'''

def calculate_evolution_remove_data_count():
    remove_count = 0
    method_file_prefix = './evolution/method_detail_to_reference_remove_'  # + '.json'
    field_file_prefix = './evolution/field_detail_to_reference_remove_'  # + '.json'
    constructor_file_prefix = './evolution/constructor_detail_to_reference_remove_'  # + '.json'
    for i in range(22, 35):
        method_file = method_file_prefix + str(i) + '_version.json'
        field_file = field_file_prefix + str(i) + '_version.json'
        constructor_file = constructor_file_prefix + str(i) + '_version.json'
        with open(method_file, 'r', encoding='utf-8') as f1:
            method_data = json.load(f1)
            for m in range(0, len(method_data)):
                remove_count += len(method_data[m]['field_detail_to_reference'])
        with open(field_file, 'r', encoding='utf-8') as f2:
            field_data = json.load(f2)
            for n in range(0, len(field_data)):
                remove_count += len(field_data[n]['field_detail_to_reference'])
        with open(constructor_file, 'r', encoding='utf-8') as f3:
            constructor_data = json.load(f3)
            for p in range(0, len(constructor_data)):
                remove_count += len(constructor_data[p]['field_detail_to_reference'])
    print("remove API count: ", remove_count)

calculate_evolution_remove_data_count()




